// Telefonda yalnız sahne görünümünde (#yayin) ekrana dokununca tam ekrana geçer. Bilgisayarda (fare) çalışmaz.
if (window.matchMedia && matchMedia('(pointer: coarse)').matches) {
  document.addEventListener('pointerdown', () => {
    const k = document.documentElement;
    if (!document.body.classList.contains('yayin') || document.fullscreenElement || document.webkitFullscreenElement) return;
    const ac = k.requestFullscreen || k.webkitRequestFullscreen;
    if (!ac) return;
    try {
      const s = ac.call(k, { navigationUI: 'hide' });
      if (s && s.then) s.then(() => { try { screen.orientation.lock('portrait').catch(() => {}); } catch (e) {} }).catch(() => {});
    } catch (e) {}
  }, true);
}
