/* FETİH 1453 — yerleşim, olaylar, hareket ve askerlerin çizimi.
 *
 * Ordu surların önünde saf saf durur, kameraya bakar; arkada sur, sağda Şahi topu. Sancaktar (lider) en önde,
 * ortada, kızıl sancağı taşır. Hediyeler: nara, mehter yürüyüşü, ok yağmuru, top atışı, karadan yürüyen gemi
 * (20-savas.js). Gök, sur ve top 30-sur.js'te.
 */

const FH_SAF = 5;          // bir safta kaç asker
const FH_ARA_X = 0.74;     // yan yana iki asker arası (metre)
const FH_ARA_Z = 1.0;      // iki saf arası
const FH_SANCAK_Z = -1.35; // sancaktar bu kadar önde
const FH_GUVERTE = 0.95;   // geminin güvertesinin yüksekliği

Object.assign(D, { surZ: 3.2, hasar: 0, gedik: [], gulle: [], oklar: [], toz: [], gemi: null, fetihBit: -1, mehterBit: -1, topAtes: -9 });

function fhHazir(k) {
  if (k.fh)
    return;
  const h = ozet(k.id);
  // kaftan rengi kişiye özgü: aynı kişi her yayında aynı renkte
  const kaftan = ['#b3262d', '#1f4f8f', '#2f6b3a', '#7a2a6e', '#b3262d', '#24305a'][h % 6];
  Object.assign(k.g, { yelek: kaftan, gomlek: '#efe3c8', kusak: '#e7b64a', baslik: 'yok' });
  k.fh = { evre: (h % 97) / 97 };
}
function fhSafSon() {
  let m = 0;
  for (const k of D.sira)
    if (!(D.gemi && D.gemi.k === k))
      m = Math.max(m, k.hedefZ);
  return m;
}
function oyunYerlesim() {
  const gemici = D.gemi ? D.gemi.k : null;
  let i = 0;
  const n0 = D.sira.length - 1 - (gemici && D.oy.has(gemici.id) ? 1 : 0);
  for (const k of D.sira) {
    fhHazir(k);
    if (k === gemici)
      continue;
    if (i === 0) {
      k.hedefX = 0;
      k.hedefZ = FH_SANCAK_Z;
      i++;
      continue;
    }
    const j = i - 1, s = Math.floor(j / FH_SAF), n = Math.min(FH_SAF, n0 - s * FH_SAF), yer = j % FH_SAF;
    k.hedefX = (yer - (n - 1) / 2) * FH_ARA_X + (s % 2 ? FH_ARA_X / 2 : 0);
    k.hedefZ = -0.25 + s * FH_ARA_Z;
    i++;
  }
  D.surHedef = fhSafSon() + 3.2;
}
function fhYari() {
  let m = 1.4;
  for (const k of D.sira)
    m = Math.max(m, Math.abs(k.hedefX));
  return m;
}
function oyunGiris(k) {
  fhHazir(k);
  // ordugâhın yanından koşarak gelir
  k.x = (k.hedefX >= 0 ? 1 : -1) * 6;
  k.z = k.hedefZ;
}
function oyunBaslat() {
  for (const k of D.sira) {
    fhHazir(k);
    k.x = k.hedefX;
    k.z = k.hedefZ;
    k.yer = 1;
    k.yon = Math.PI;
    k.yeni = -9;
  }
  D.surZ = D.surHedef || 3.2;
}
function oyunBosalt() {
  Object.assign(D, { hasar: 0, gedik: [], gulle: [], oklar: [], toz: [], gemi: null, fetihBit: -1, mehterBit: -1, topAtes: -9 });
  muzik.sov = false;
}

/* ---- olaylar ---- */
function oyunHediye(k, jeton, kademe) {
  fhHazir(k);
  const tip = kademe.tip;
  if (tip === 'mehter')
    D.mehterBit = Math.max(D.mehterBit, B) + 4;
  else if (tip === 'ok')
    fhOkYagmuru(k);
  else if (tip === 'top')
    fhTopAt();
  else if (tip === 'gemi') {
    if (D.gemi)
      D.gemi.k.yildiz = false;
    D.gemi = { k, b0: B, sure: 12 };
    k.yildiz = true;
    D.mehterBit = B + 12;
    pankart('Gemiler karadan!', k.ad);
    konfeti(50, 0.7);
  }
}
function oyunLiderDegisti(eski, yeni) {
  pankart('Sancak yeni elde', yeni.ad);
  konfeti(60, 0.8);
}

/* ---- her kare ---- */
function oyunGuncelle(dt) {
  muzik.sov = B < D.mehterBit || B < D.fetihBit;
  D.surZ += ((D.surHedef || 3.2) - D.surZ) * Math.min(1, dt * 2);
  fhSavasGuncelle(dt);
  const mehter = B < D.mehterBit;
  for (const k of D.oy.values()) {
    fhHazir(k);
    if (D.gemi && D.gemi.k === k) {
      // güvertede: gemiyle birlikte gider
      const g = fhGemiYer();
      k.x = g.x;
      k.z = g.z;
      k.y0 = FH_GUVERTE;
      k.yer = 1;
      k.yon += aciFark(k.yon, Math.PI) * Math.min(1, dt * 6);
      fhPoz(k, false);
      continue;
    }
    const hx = k.cikiyor ? (k.x >= 0 ? 1 : -1) * 7 : k.hedefX, hz = k.hedefZ;
    const dx = hx - k.x, dz = hz - k.z, uz = Math.hypot(dx, dz);
    if (uz > 0.002) {
      const adim = Math.min(uz, (2.4 + uz * 1.3) * dt);
      k.x += dx / uz * adim;
      k.z += dz / uz * adim;
    }
    k.y0 = (k.y0 || 0) * Math.max(0, 1 - dt * 6);
    k.yer += ((uz < 0.16 && !k.cikiyor ? 1 : 0) - k.yer) * Math.min(1, dt * 7);
    if (k.cikiyor)
      k.gitti = Math.abs(k.x) > 6.5;
    // mehter adımı: dört vuruşta bir sağa sola dönüş
    const don = mehter && uz < 0.3 ? 0.5 * Math.sin(TAU * (B / 4)) : 0;
    const bak = uz > 0.3 ? Math.atan2(dx, dz) : Math.PI + don;
    k.yon += aciFark(k.yon, bak) * Math.min(1, dt * 8);
    k.basOlcek = k === D.lider ? 1.15 : undefined;
    fhPoz(k, mehter);
  }
}
function fhPoz(k, mehter) {
  const poz = pozBekle(k), sancak = k === D.lider && !k.yildiz;
  const nara = B >= k.zip0 && B < k.zip1, zipla = nara ? 0.3 * Math.abs(Math.sin(Math.PI * (B - k.zip0))) : 0;
  if (mehter) {
    // ağır, vurgulu adım: her vuruşta bir ayak kalkar
    const t = ((B % 2) + 2) % 2;
    poz.aS[2] += t < 1 ? 0.12 * Math.sin(Math.PI * t) : 0;
    poz.aL[2] += t >= 1 ? 0.12 * Math.sin(Math.PI * (t - 1)) : 0;
  }
  poz.hipY += zipla;
  poz.aS[2] += zipla * 0.8;
  poz.aL[2] += zipla * 0.8;
  const W = iskeletKur(k, poz), hy = poz.hipY, okAt = B < (k.okBit || -1);
  if (sancak || k.yildiz) {
    // sancak iki elle, gövdenin sağında
    k.j.haR = W(-0.24, hy + 0.62, 0.12);
    k.j.haL = W(-0.16, hy + 0.32, 0.14);
    k.elSekil = { R: 'yumruk', L: 'yumruk' };
    k.sancakAlt = W(-0.25, hy - 0.45, 0.12);
    k.sancakUst = W(-0.27, hy + 2.25, 0.11);
  }
  else {
    k.sancakAlt = null;
    if (nara) {
      k.j.haR = W(-0.2, hy + 0.95, 0.05);
      k.j.haL = W(0.2, hy + 0.06, 0.05);
      k.elSekil = { R: 'yumruk' };
    }
    else if (okAt) {
      // yay gerer: sol kol öne ve yukarı, sağ el göğse çekilmiş
      k.j.haL = W(0.08, hy + 0.72, 0.42);
      k.j.haR = W(-0.08, hy + 0.6, 0.1);
      k.elSekil = { R: 'yumruk', L: 'yumruk' };
      k.yay = W(0.08, hy + 0.72, 0.42);
    }
    else if (mehter) {
      const s = Math.sin(TAU * B / 2) * 0.12;
      k.j.haR = W(-0.24, hy + 0.12, s);
      k.j.haL = W(0.24, hy + 0.12, -s);
      k.elSekil = null;
    }
    else {
      k.j.haR = W(-0.2, hy + 0.06, 0.05);
      k.j.haL = W(0.2, hy + 0.06, 0.05);
      k.elSekil = null;
    }
    if (!okAt)
      k.yay = null;
  }
  kolKur(k);
}
function oyunKamera() {
  const yari = fhYari(), n = [[yari + 1.45, -0.7], [-yari, -0.7], [1.6, FH_SANCAK_Z - 0.3], [-1.6, FH_SANCAK_Z - 0.3]];
  for (const k of D.sira)
    n.push([k.hedefX, k.hedefZ]);
  return n;
}
function oyunCiz() {
  for (const k of D.oy.values()) {
    if (!insanEkle(k))
      continue;
    if (k.hedefZ < 0.4 && k !== D.lider && !k.yildiz)
      k.et.asagi = true;
    fhBorkEkle(k);
    if (k.sancakAlt)
      fhSancakEkle(k);
    if (k.yay)
      fhYayEkle(k);
  }
  fhTopEkle();
  fhSavasEkle();
}
function oyunDurum(d) {
  d.sancaktar = D.lider ? D.lider.ad : null;
  d.hasar = +D.hasar.toFixed(2);
  d.gemi = D.gemi ? D.gemi.k.ad : null;
  d.fetih = B < D.fetihBit;
}
