/* SAVAŞ — ok yağmuru, Şahi topu ve güllesi, toz bulutları, karadan yürüyen gemi, fetih anı; börk, sancak, yay.
 * Hedef hep surdur: kimse yaralanmaz. Bütün süreler vuruşla (B) ölçülür.
 */

const FH_OK_SURE = 1.2, FH_GULLE_SURE = 1.4;

// Şahi topu ordunun sağında, namlusu surun ortasına bakar.
function fhTopYer() {
  const x = fhYari() + 0.95, z = -0.75, hedef = [x * 0.3, 1.8, D.surZ], dx = hedef[0] - x, dz = hedef[2] - z, uz = Math.hypot(dx, dz);
  const yon = [dx / uz, dz / uz], egim = 0.18;
  return { x, z, yon, dip: [x - yon[0] * 0.7, 0.55, z - yon[1] * 0.7], agiz: [x + yon[0] * 1.15, 0.55 + egim * 1.85, z + yon[1] * 1.15] };
}
function fhTopAt() {
  const t = fhTopYer();
  D.topAtes = B;
  D.sarsinti = Math.max(D.sarsinti, 0.5);
  D.gulle.push({ b0: B, p0: t.agiz.slice(), p1: [(Math.random() - 0.5) * 6, 1.1 + Math.random() * 1.5, D.surZ - 0.05] });
  fhToz(t.agiz[0], t.agiz[1], t.agiz[2], 0.5, '#d9d2c2');
}
function fhOkYagmuru(k) {
  let i = 0;
  for (const s of D.sira) {
    if (s.yildiz || i >= 36)
      continue;
    s.okBit = B + 1.6;
    D.oklar.push({ b0: B + 0.5 + (i % 5) * 0.08, p0: [s.x, 1.45, s.z - 0.2], p1: [(Math.random() - 0.5) * 9, 2.9 + Math.random() * 0.6, D.surZ + 0.15] });
    i++;
  }
  k.okBit = B + 1.6;
}
function fhToz(x, y, z, r, renk) {
  if (D.toz.length < 40)
    D.toz.push({ x, y, z, r, renk, b0: B });
}
function fhFetih(baslik, ad) {
  D.fetihBit = B + 10;
  D.hasar = 1;
  pankart(baslik, ad);
  konfeti(120, 1);
  D.sarsinti = 0.6;
}
function fhGemiYer() {
  const g = D.gemi, u = clamp((B - g.b0) / g.sure, 0, 1);
  return { u, x: -8 + 16 * u, z: fhSafSon() + 1.65 };
}
function fhSavasGuncelle(dt) {
  for (let i = D.gulle.length - 1; i >= 0; i--) {
    const g = D.gulle[i];
    if (B - g.b0 >= FH_GULLE_SURE) {
      D.gulle.splice(i, 1);
      D.hasar = Math.min(1, D.hasar + 0.25);
      if (D.gedik.length < 12)
        D.gedik.push({ x: g.p1[0], y: g.p1[1], r: 0.45 + Math.random() * 0.25, h: Math.floor(Math.random() * 1000) });
      fhToz(g.p1[0], g.p1[1], g.p1[2] - 0.2, 0.9, '#c9b896');
      D.sarsinti = Math.max(D.sarsinti, 0.6);
      if (D.hasar >= 1 && B >= D.fetihBit)
        fhFetih('Surda gedik açıldı!', D.lider ? D.lider.ad : '');
    }
  }
  for (let i = D.oklar.length - 1; i >= 0; i--)
    if (B - D.oklar[i].b0 >= FH_OK_SURE) {
      D.hasar = Math.min(0.95, D.hasar + 0.006);
      D.oklar.splice(i, 1);
    }
  for (let i = D.toz.length - 1; i >= 0; i--)
    if (B - D.toz[i].b0 > 2.5 || B < D.toz[i].b0)
      D.toz.splice(i, 1);
  // fetih bitince sur onarılır, yeni kuşatma başlar
  if (D.fetihBit > 0 && B > D.fetihBit) {
    D.fetihBit = -1;
    D.hasar = 0;
    D.gedik.length = 0;
  }
  const g = D.gemi;
  if (g && (g.k.cikiyor || B - g.b0 >= g.sure)) {
    const k = g.k;
    k.yildiz = false;
    D.gemi = null;
    k.x = 6.5;
    k.y0 = 0;
    oyunYerlesim();
    if (!k.cikiyor)
      fhFetih('Fetih!', k.ad);
  }
}

/* ---- çizim ---- */
function fhBorkEkle(k) {
  const ph = k.p.kafa;
  if (!ph || !ph.ok)
    return;
  const R = KAFA_R * k.g.boy * (k.basOlcek || 1) * ph.s, sancaktar = k === D.lider;
  ozel(ph.d - 0.06, () => {
    const x = ph.x, y = ph.y, cz = Math.max(1, ph.s * 0.012);
    c.lineWidth = cz;
    c.strokeStyle = MUREKKEP;
    // beyaz keçe börk: tepesi arkaya doğru hafif yatık
    c.fillStyle = '#f4efe2';
    c.beginPath();
    c.moveTo(x - R * 0.78, y - R * 0.5);
    c.quadraticCurveTo(x - R * 0.82, y - R * 1.7, x - R * 0.35, y - R * 2.35);
    c.quadraticCurveTo(x + R * 0.25, y - R * 2.55, x + R * 0.55, y - R * 2.05);
    c.quadraticCurveTo(x + R * 0.82, y - R * 1.3, x + R * 0.78, y - R * 0.5);
    c.closePath();
    c.fill();
    c.stroke();
    c.fillStyle = '#e7b64a';
    c.beginPath();
    c.moveTo(x - R * 0.82, y - R * 0.48);
    c.lineTo(x - R * 0.8, y - R * 0.78);
    c.lineTo(x + R * 0.8, y - R * 0.78);
    c.lineTo(x + R * 0.82, y - R * 0.48);
    c.closePath();
    c.fill();
    c.stroke();
    // önde kaşıklık; sancaktarınkinde kızıl sorguç
    c.beginPath();
    c.ellipse(x, y - R * 0.95, R * 0.13, R * 0.24, 0, 0, TAU);
    c.fill();
    c.stroke();
    if (sancaktar) {
      c.fillStyle = '#d7263d';
      c.beginPath();
      c.moveTo(x, y - R * 1.15);
      c.quadraticCurveTo(x - R * 0.5, y - R * 2.2, x + R * 0.1, y - R * 2.9);
      c.quadraticCurveTo(x + R * 0.15, y - R * 2.0, x + R * 0.12, y - R * 1.15);
      c.closePath();
      c.fill();
      c.stroke();
    }
  });
}
// Kızıl sancak: iki elle tutulan direk, rüzgârda dalgalanan bez, beyaz hilal.
function fhSancakEkle(k) {
  const ha = k.p.haR;
  if (!ha || !ha.ok)
    return;
  const a = pr(k.sancakAlt), u = pr(k.sancakUst);
  if (!a.ok || !u.ok)
    return;
  const ust = k.sancakUst, L = 0.95, H = 0.55, N = 10, ustK = [], altK = [];
  for (let i = 0; i <= N; i++) {
    const t = i / N, dal = 0.09 * t * Math.sin(TAU * (B / 2 - t * 1.1)), sark = 0.1 * t * t;
    ustK.push(pr([ust[0] + t * L, ust[1] + dal - sark, ust[2] + dal * 0.5]));
    altK.push(pr([ust[0] + t * L, ust[1] - H + dal - sark * 1.4, ust[2] + dal * 0.5]));
  }
  if (ustK.some(p => !p.ok) || altK.some(p => !p.ok))
    return;
  ozel(ha.d - 0.03, () => {
    const cz = Math.max(1, a.s * 0.01);
    kapsulCiz(a, 0.025, u, 0.022, '#4a2e1c', cz);
    c.lineWidth = cz;
    c.strokeStyle = MUREKKEP;
    c.fillStyle = '#c8102e';
    c.beginPath();
    c.moveTo(ustK[0].x, ustK[0].y);
    for (const p of ustK)
      c.lineTo(p.x, p.y);
    for (let i = N; i >= 0; i--)
      c.lineTo(altK[i].x, altK[i].y);
    c.closePath();
    c.fill();
    c.stroke();
    // hilal: bezin ortasına yakın, beyaz daireden kızıl daire oyulur
    const m = 4, cx = (ustK[m].x + altK[m].x) / 2, cy = (ustK[m].y + altK[m].y) / 2, r = Math.abs(altK[m].y - ustK[m].y) * 0.3;
    c.fillStyle = '#fbf6ea';
    c.beginPath();
    c.arc(cx, cy, r, 0, TAU);
    c.fill();
    c.fillStyle = '#c8102e';
    c.beginPath();
    c.arc(cx + r * 0.35, cy, r * 0.82, 0, TAU);
    c.fill();
    const tp = pr([ust[0], ust[1] + 0.12, ust[2]]);
    if (tp.ok)
      daireCiz(tp, 0.05, '#e7b64a', cz);
  });
}
function fhYayEkle(k) {
  const p = pr(k.yay);
  if (!p.ok)
    return;
  ozel(p.d - 0.03, () => {
    c.strokeStyle = '#5a3a1e';
    c.lineWidth = Math.max(1.5, p.s * 0.02);
    c.beginPath();
    c.ellipse(p.x, p.y, 0.06 * p.s, 0.26 * p.s, 0, -HP, HP);
    c.stroke();
    c.strokeStyle = 'rgba(255,255,255,0.7)';
    c.lineWidth = 1;
    c.beginPath();
    c.moveTo(p.x, p.y - 0.26 * p.s);
    c.lineTo(p.x - 0.05 * p.s, p.y);
    c.lineTo(p.x, p.y + 0.26 * p.s);
    c.stroke();
  });
}
// Şahi topu: tahta kızak üstünde tunç namlu; ateşte ağızda alev.
function fhTopEkle() {
  const t = fhTopYer(), m = pr([t.x, 0.4, t.z]);
  if (!m.ok)
    return;
  const dip = pr(t.dip), agiz = pr(t.agiz);
  ozel(m.d, () => {
    const cz = Math.max(1, m.s * 0.01), aci = Math.atan2(t.yon[0], t.yon[1]);
    const T = donusum(t.x, 0, t.z, aci, 1);
    kutuCiz(T, -0.42, 0.42, 0, 0.32, -0.9, 0.9, '#6b4423', cz);
    for (const s of [-1, 1])
      for (const ic of [-0.6, 0.6]) {
        const w = pr(yerelNokta(T, s * 0.45, 0.2, ic));
        if (w.ok)
          daireCiz(w, 0.2, '#4a2e1c', cz);
      }
    const ates = B - D.topAtes;
    if (dip.ok && agiz.ok) {
      kapsulCiz(dip, 0.3, agiz, 0.24, '#b5803a', cz);
      daireCiz(agiz, 0.17, '#2a1a10', cz);
      if (ates >= 0 && ates < 0.35) {
        const r = (0.6 + ates * 2) * agiz.s;
        c.fillStyle = 'rgba(255,200,80,' + (1 - ates / 0.35) + ')';
        c.beginPath();
        for (let i = 0; i < 16; i++) {
          const a = i / 16 * TAU, rr = i % 2 ? r * 0.45 : r;
          c.lineTo(agiz.x + Math.cos(a) * rr, agiz.y + Math.sin(a) * rr);
        }
        c.closePath();
        c.fill();
      }
    }
  });
}
// Uçan gülle ve oklar, toz bulutları, gemi.
function fhSavasEkle() {
  for (const g of D.gulle) {
    const t = clamp((B - g.b0) / FH_GULLE_SURE, 0, 1), w = [lerp(g.p0[0], g.p1[0], t), lerp(g.p0[1], g.p1[1], t) + Math.sin(Math.PI * t) * 1.6, lerp(g.p0[2], g.p1[2], t)], p = pr(w);
    if (p.ok)
      ozel(p.d, () => daireCiz(p, 0.17, '#2b2b30', Math.max(1, p.s * 0.01)));
  }
  for (const o of D.oklar) {
    const t = (B - o.b0) / FH_OK_SURE;
    if (t < 0 || t > 1)
      continue;
    const yer = tt => [lerp(o.p0[0], o.p1[0], tt), lerp(o.p0[1], o.p1[1], tt) + Math.sin(Math.PI * tt) * 2.2, lerp(o.p0[2], o.p1[2], tt)];
    const p = pr(yer(t)), q = pr(yer(Math.max(0, t - 0.06)));
    if (!p.ok || !q.ok)
      continue;
    ozel(p.d, () => {
      const dx = p.x - q.x, dy = p.y - q.y, uz = Math.hypot(dx, dy) || 1, L = 0.55 * p.s;
      const bx = p.x - dx / uz * L, by = p.y - dy / uz * L;
      c.strokeStyle = '#3a2a1c';
      c.lineWidth = Math.max(1, p.s * 0.012);
      c.beginPath();
      c.moveTo(bx, by);
      c.lineTo(p.x, p.y);
      c.stroke();
      c.strokeStyle = '#f4efe2';
      c.beginPath();
      c.moveTo(bx, by);
      c.lineTo(bx + dx / uz * L * 0.2 - dy / uz * L * 0.1, by + dy / uz * L * 0.2 + dx / uz * L * 0.1);
      c.stroke();
    });
  }
  for (const s of D.toz) {
    const t = (B - s.b0) / 2.5, p = pr([s.x, s.y + t * 0.6, s.z]);
    if (!p.ok)
      continue;
    ozel(p.d, () => {
      c.globalAlpha = 0.75 * (1 - t);
      c.fillStyle = s.renk;
      for (let i = 0; i < 6; i++) {
        const a = i / 6 * TAU + s.b0, r = s.r * p.s * (0.45 + t * 0.9);
        c.beginPath();
        c.arc(p.x + Math.cos(a) * r * 0.7, p.y + Math.sin(a) * r * 0.4, r * 0.6, 0, TAU);
        c.fill();
      }
      c.globalAlpha = 1;
    });
  }
  if (D.gemi)
    fhGemiEkle();
}
// Kadırga: kızaklar üstünde, gövdesi yandan görünür; latin yelkeninde hilal. Güvertedeki kişiyi insanEkle çizer.
function fhGemiEkle() {
  const g = fhGemiYer(), m = pr([g.x, 0.6, g.z + 0.45]);
  if (!m.ok)
    return;
  ozel(m.d, () => {
    const cz = Math.max(1, m.s * 0.01), sal = 0.03 * Math.sin(TAU * B / 2);
    const T = donusum(g.x, 0.3 + sal, g.z + 0.05, Math.PI / 2, 1);
    kutuCiz(T, -0.55, 0.55, 0, FH_GUVERTE - 0.3, -2.3, 2.3, '#7a4a26', cz);
    // baş ve kıç: yukarı kalkık uçlar
    for (const s of [-1, 1])
      yuzCiz(T, [[-0.56, FH_GUVERTE - 0.32, s * 2.3], [-0.56, FH_GUVERTE + 0.25, s * 2.75], [-0.56, FH_GUVERTE - 0.32, s * 2.05]], '#5e3a1e', cz);
    // kürekler: gövdenin yanından yere doğru
    c.strokeStyle = '#4a2e1c';
    c.lineWidth = Math.max(1, m.s * 0.015);
    for (let i = -3; i <= 3; i++) {
      const a = pr(yerelNokta(T, -0.56, 0.35, i * 0.6)), b = pr(yerelNokta(T, -1.2, -0.25, i * 0.6 + 0.25 * Math.sin(TAU * B / 2 + i)));
      if (a.ok && b.ok) {
        c.beginPath();
        c.moveTo(a.x, a.y);
        c.lineTo(b.x, b.y);
        c.stroke();
      }
    }
    const d1 = pr(yerelNokta(T, 0, FH_GUVERTE - 0.3, 0.3)), d2 = pr(yerelNokta(T, 0, 3.2, 0.3));
    if (d1.ok && d2.ok)
      kapsulCiz(d1, 0.05, d2, 0.04, '#4a2e1c', cz);
    const yel = yuzCiz(T, [[0.02, 3.1, 1.6], [0.02, 1.25, 1.4], [0.02, 1.1, -1.9]], '#f2ead6', cz);
    if (yel) {
      const cx = (yel[0].x + yel[1].x + yel[2].x) / 3, cy = (yel[0].y + yel[1].y + yel[2].y) / 3, r = 0.22 * m.s;
      c.fillStyle = '#c8102e';
      c.beginPath();
      c.arc(cx, cy, r, 0, TAU);
      c.fill();
      c.fillStyle = '#f2ead6';
      c.beginPath();
      c.arc(cx + r * 0.35, cy, r * 0.82, 0, TAU);
      c.fill();
    }
  });
}
