/* SUR — şafak göğü, uzaktaki kubbeler, tuğla kuşaklı taş sur ve burçlar, kapı, gedikler, burca dikilen sancak,
 * ordugâh toprağı ve gemi kızakları. Hepsi zeminde doğrudan c ile çizilir (herkesin arkasında kalır).
 */

const FH_TAS = '#b9a98a', FH_TAS2 = '#9c8c70', FH_TUGLA = '#a4553a', FH_SUR_H = 3.0, FH_BURC_H = 4.1;

function oyunZemin() {
  const z = D.surZ;
  gokCiz({ gok: ['#1b2550', '#5a4a86', '#d9809a', '#ffc98a'], zemin: ['#8d7a52', '#6a5a3a'], pus: '#ffd9b0', gunes: { x: 0.78, r: 34, renk: '#ffe7b8', isik: '#ffb070' } });
  fhKubbeler(z + 7);
  fhSur(z);
  if (D.gemi)
    fhKizak();
  for (const k of D.oy.values())
    if (!(D.gemi && D.gemi.k === k))
      golge(k.x, k.z, 0.25 * k.g.boy, 0.13 * k.g.boy);
  if (D.lider && !D.lider.yildiz) {
    const p = pr([D.lider.x, 0, D.lider.z]);
    if (p.ok) {
      const n = 1 + 0.08 * Math.sin(B * TAU);
      c.strokeStyle = RENK.vurgu;
      c.lineWidth = Math.max(2, p.s * 0.03);
      c.beginPath();
      c.ellipse(p.x, p.y, 0.42 * p.s * n, 0.2 * p.s * n, 0, 0, TAU);
      c.stroke();
    }
  }
}
// Surun ardında şehrin kubbeleri: gökten bir ton koyu, düz siluet.
function fhKubbeler(z) {
  c.fillStyle = '#4a3e6a';
  for (const [x, r, h] of [[-6.5, 1.1, 2.6], [-3.6, 0.8, 3.2], [-0.4, 2.0, 4.2], [3.2, 1.2, 3.0], [6.2, 0.9, 2.4], [9, 1.3, 2.8], [-9.5, 1.0, 2.2]]) {
    const a = pr([x - r, 0, z]), b = pr([x + r, h, z]), m = pr([x, h, z]);
    if (!a.ok || !b.ok || !m.ok)
      continue;
    const R = Math.abs(b.x - a.x) / 2;
    c.fillRect(a.x, m.y, b.x - a.x, a.y - m.y);
    c.beginPath();
    c.ellipse(m.x, m.y, R, R * 0.85, 0, Math.PI, TAU);
    c.fill();
  }
}
function fhYuz(pts, renk) {
  c.beginPath();
  pts.forEach((p, i) => i ? c.lineTo(p.x, p.y) : c.moveTo(p.x, p.y));
  c.closePath();
  c.fillStyle = renk;
  c.fill();
  c.stroke();
}
// Sur: perdeler ve öne taşan burçlar; mazgallar, iki tuğla kuşağı, ortada kapı, gülle izleri.
function fhSur(z) {
  const X = 13, burclar = [-9, -5.4, -1.8, 1.8, 5.4, 9];
  const a = pr([-X, 0, z]);
  if (!a.ok)
    return;
  c.strokeStyle = MUREKKEP;
  c.lineWidth = Math.max(1, a.s * 0.01);
  // perde duvar
  const p = (x, y, zz) => pr([x, y, zz === undefined ? z : zz]);
  fhYuz([p(-X, 0), p(X, 0), p(X, FH_SUR_H), p(-X, FH_SUR_H)], FH_TAS);
  for (const y of [1.0, 2.0])
    fhYuz([p(-X, y), p(X, y), p(X, y + 0.22), p(-X, y + 0.22)], FH_TUGLA);
  for (let x = -X; x < X; x += 0.6)
    fhYuz([p(x, FH_SUR_H), p(x + 0.32, FH_SUR_H), p(x + 0.32, FH_SUR_H + 0.32), p(x, FH_SUR_H + 0.32)], FH_TAS2);
  // kapı
  const k1 = p(-0.65, 0), k2 = p(0.65, 0), kt = p(0, 1.75);
  c.fillStyle = '#2a1c18';
  c.beginPath();
  c.moveTo(k1.x, k1.y);
  c.lineTo(k1.x, kt.y + (k2.x - k1.x) * 0.5);
  c.arc(kt.x, kt.y + (k2.x - k1.x) * 0.5, (k2.x - k1.x) / 2, Math.PI, TAU);
  c.lineTo(k2.x, k2.y);
  c.closePath();
  c.fill();
  c.stroke();
  // gülle izleri ve gedikler
  for (const g of D.gedik) {
    const m = p(g.x, g.y, z - 0.01), r = g.r * m.s;
    if (!m.ok)
      continue;
    c.fillStyle = '#4a3e30';
    c.beginPath();
    for (let i = 0; i < 9; i++) {
      const aa = i / 9 * TAU, rr = r * (0.6 + ((g.h >> i) & 3) * 0.15);
      c.lineTo(m.x + Math.cos(aa) * rr, m.y + Math.sin(aa) * rr * 0.8);
    }
    c.closePath();
    c.fill();
    c.strokeStyle = '#3a2e22';
    c.lineWidth = Math.max(1, m.s * 0.012);
    for (let i = 0; i < 4; i++) {
      const aa = i * 1.7 + g.h, uz = r * (1.4 + (i % 2) * 0.5);
      c.beginPath();
      c.moveTo(m.x + Math.cos(aa) * r * 0.6, m.y + Math.sin(aa) * r * 0.5);
      c.lineTo(m.x + Math.cos(aa + 0.2) * uz, m.y + Math.sin(aa + 0.2) * uz * 0.8);
      c.stroke();
    }
    c.strokeStyle = MUREKKEP;
    c.lineWidth = Math.max(1, a.s * 0.01);
  }
  // burçlar: perdeden yüksek, önden düz görünür
  const zb = z - 0.05, w = 0.75;
  burclar.forEach(x => {
    fhYuz([p(x - w, 0, zb), p(x + w, 0, zb), p(x + w, FH_BURC_H, zb), p(x - w, FH_BURC_H, zb)], FH_TAS);
    fhYuz([p(x - w, 1.0, zb), p(x + w, 1.0, zb), p(x + w, 1.22, zb), p(x - w, 1.22, zb)], FH_TUGLA);
    fhYuz([p(x - w, 2.4, zb), p(x + w, 2.4, zb), p(x + w, 2.62, zb), p(x - w, 2.62, zb)], FH_TUGLA);
    for (let i = 0; i < 3; i++) {
      const x0 = x - w + i * 0.55;
      fhYuz([p(x0, FH_BURC_H, zb), p(x0 + 0.35, FH_BURC_H, zb), p(x0 + 0.35, FH_BURC_H + 0.35, zb), p(x0, FH_BURC_H + 0.35, zb)], FH_TAS2);
    }
    // mazgal penceresi
    const m1 = p(x - 0.12, 2.9, zb - 0.01), m2 = p(x + 0.12, 3.5, zb - 0.01);
    c.fillStyle = '#2a1c18';
    c.fillRect(m1.x, m2.y, m2.x - m1.x, m1.y - m2.y);
  });
  // fetih: kapının üstündeki surun burcuna sancak dikilir
  if (B < D.fetihBit)
    fhBurcSancak(z, D.fetihBit - 10);
}
function fhBurcSancak(z, b0) {
  const t = clamp((B - b0) / 1.5, 0, 1), alt = pr([0, FH_SUR_H + 0.3, z - 0.05]), ustY = FH_SUR_H + 0.3 + 2.2 * yumusak(t), ust = pr([0, ustY, z - 0.05]);
  if (!alt.ok || !ust.ok)
    return;
  const cz = Math.max(1, alt.s * 0.012);
  kapsulCiz(alt, 0.05, ust, 0.04, '#4a2e1c', cz);
  const L = 1.6, H = 1.0, N = 10, u = [], a = [];
  for (let i = 0; i <= N; i++) {
    const s = i / N, dal = 0.14 * s * Math.sin(TAU * (B / 2 - s * 1.1));
    u.push(pr([s * L, ustY + dal, z - 0.05]));
    a.push(pr([s * L, ustY - H + dal - 0.1 * s, z - 0.05]));
  }
  if (u.some(q => !q.ok) || a.some(q => !q.ok))
    return;
  c.lineWidth = cz;
  c.strokeStyle = MUREKKEP;
  c.fillStyle = '#c8102e';
  c.beginPath();
  u.forEach((q, i) => i ? c.lineTo(q.x, q.y) : c.moveTo(q.x, q.y));
  for (let i = N; i >= 0; i--)
    c.lineTo(a[i].x, a[i].y);
  c.closePath();
  c.fill();
  c.stroke();
  const cx = (u[4].x + a[4].x) / 2, cy = (u[4].y + a[4].y) / 2, r = Math.abs(a[4].y - u[4].y) * 0.3;
  c.fillStyle = '#fbf6ea';
  c.beginPath();
  c.arc(cx, cy, r, 0, TAU);
  c.fill();
  c.fillStyle = '#c8102e';
  c.beginPath();
  c.arc(cx + r * 0.35, cy, r * 0.82, 0, TAU);
  c.fill();
}
// Gemi yolunda yağlanmış kızak kütükleri.
function fhKizak() {
  const z = fhGemiYer().z;
  c.lineWidth = 1;
  for (let x = -9; x <= 9; x += 0.7) {
    const a = pr([x, 0.05, z - 0.7]), b = pr([x, 0.05, z + 0.8]);
    if (!a.ok || !b.ok)
      continue;
    c.strokeStyle = '#4a2e1c';
    c.lineWidth = Math.max(2, a.s * 0.09);
    c.beginPath();
    c.moveTo(a.x, a.y);
    c.lineTo(b.x, b.y);
    c.stroke();
    c.strokeStyle = '#8a5a32';
    c.lineWidth = Math.max(1, a.s * 0.05);
    c.stroke();
  }
}
