/* AYAR — Fetih 1453 oyununun bütün yazıları, hediye kademeleri, açılış kalabalığı ve sahte yorumları.
 * Derlemede HER ZAMAN İLK dosyadır; çekirdek OYUN'u buradan okur (docs/KANCALAR.md).
 * Oyun: şafak vakti, surların önünde ordu. Yorum yazan börkünü giyip saflara girer. Hediyeler mehter yürüyüşü,
 * ok yağmuru ve Şahi topunu başlatır; top gülleleri surda gedik açar, gedik tamamlanınca sancak burca dikilir.
 * En çok hediye atan sancaktar olur, en önde sancağı o taşır. En büyük hediyede gemi karadan yürür, gönderen
 * güvertededir. Kimse yaralanmaz, kimse düşmez: hedef hep surdur.
 */
const OYUN = {
  id: 'fetih',
  ad: 'Fetih 1453',
  logo: ['Fetih', '1453'],
  nasil: { yorum: 'Yorum: saflara katıl', begeni: 'Beğeni: azim', hediye: 'Hediye: sura yüklen' },
  yazi: {
    sira: 'Saf sırası', gosterge: 'Azim', bos: 'Ordugâh boş. İlk gelen sancağı taşır.',
    birim: 'asker', ses: 'Mehteri başlat', sahne: 'Fetih sahnesi', giris: 'saflara katılır',
    bosalt: 'Ordugâhı boşalt'
  },
  kapasite: 32,
  // Büyükten küçüğe.
  kademe: [
    { min: 1000, ad: 'Gemiler karadan', tip: 'gemi', etki: 'Gemi kızakların üstünden yürür, gönderen güvertede; ardından sancak burca' },
    { min: 200, ad: 'Şahi topu', tip: 'top', etki: 'Dev top gürler, gülle surda gedik açar' },
    { min: 50, ad: 'Ok yağmuru', tip: 'ok', etki: 'Bütün ordu surun üstüne ok atar' },
    { min: 10, ad: 'Mehter', tip: 'mehter', etki: 'Herkes mehter adımıyla yürür' },
    { min: 1, ad: 'Nara', tip: 'nara', etki: 'Gönderen yumruğunu kaldırıp zıplar' }
  ],
  tohum: [['sancaktar_ali', 320], ['zeyno.47', 140], ['akıncı.cemo', 60], ['topçu_urban', 25], ['elif_naz', 10], ['hasan.usta', 5], ['pınar_34', 0], ['nur.sena', 0], ['mert.can.21', 0]],
  sahteAd: ['sancaktar_ali', 'akıncı.cemo', 'topçu_hasan', 'zeyno.47', 'elif_naz', 'hasan.usta', 'pınar_34', 'nur.sena', 'mert.can.21', 'sibel_abla', 'ozan_dayı', 'yusuf.63', 'nazlı_can', 'şahin_k', 'melo.27', 'kemo_44', 'hüso_baba', 'selo_02', 'laz_ziya', 'baran.21', 'tarih_hocası', 'mehter_rıza', 'sipahi.efe', 'ok_ustası_sude', 'kale_kemal', 'muhtar_emmi', 'cano_23', 'bozkır_ali', 'akşemsettin_fan', 'yeniçeri.03'],
  sahteYorum: ['yüklen!', 'mehter başlasın', 'sancak nerede?', 'top hazır mı', 'ok yağmuru!', 'gemiler karadan', 'saflara katıldım', 'surda gedik açıldı mı', 'sabah namazına az kaldı', 'azim azim', 'ben de geldim', 'adımı gördüm', '1453!', 'Haliç’e gemi indi', 'börküm yakıştı mı', 'şafak söküyor'],
  // Şafak: lacivertten pembe-turuncuya dönen gök, taş sur, kızıl sancak.
  renk: { zemin: '#16203f', zemin2: '#24305a', zemin3: '#3b4a7a', cizgi: '#55649a', vurgu: '#ffd166', sicak: '#e23d2f', serin: '#59c3c3', soluk: '#b8b4c8' },
  kamera: { egim: 0.62, F: 1400, ustPay: 2.3, altPay: 0.1 },
  etiket: { ustSinir: true, altSinir: true, disari: 'gizle', balonSira: 'derinlik' },
  sahneYazi: { pankart: 'alt' },
  // Takım: davul zurna (mehterin özü: davul ve zurna). İki özgün mehter havası; bilinen marşlardan alıntı yok.
  muzik: {
    takim: 'davul-zurna',
    havalar: [
      { id: 'sefer', ad: 'Sefer', bpm: 92, spb: 4, bar: 16, tonik: 293.7,
        dizi: [0, 110, 390, 500, 700, 800, 1000],                       // hicaz
        davul: { ana: 'D..kD.T.D..kT.T.', cesni: 'D..kD.TkD.kkT.T.', gecis: 'D.T.D.T.DkTkTTTT' },
        bolum: {
          A: '0:4 1:2 2:2 3:4 4:4 | 4:2 5:2 4:2 3:2 2:4 3:4 | 4:4 5:2 6:2 5:2 4:2 3:4 | 2:2 1:2 2:2 1:2 0:8',
          B: '7:4 7:2 6:2 5:4 6:4 | 5:2 4:2 5:2 6:2 7:8 | 6:2 5:2 4:2 3:2 4:4 3:4 | 2:2 1:2 0:4 0~:8',
          D: '-:16 -:16'
        },
        form: 'AABBD' },
      { id: 'zafer', ad: 'Zafer', bpm: 116, spb: 4, bar: 8, tonik: 349.2,
        dizi: [0, 200, 350, 500, 700, 900, 1050],                       // rast
        davul: { ana: 'D.kTD.T.', cesni: 'D.kTDkTk', gecis: 'DkTkTkTT' },
        bolum: {
          A: '0:2 0:1 1:1 2:2 3:2 | 4:4 3:2 2:2 | 3:2 4:2 5:2 4:2 | 3:4 2:4 | 4:2 4:1 5:1 6:2 5:2 | 4:2 3:2 2:4 | 1:2 2:1 1:1 0:2 -1:2 | 0:8',
          B: '7:4 6:2 5:2 | 6:2 5:2 4:4 | 5:2 4:2 3:2 4:2 | 5:4 -:4 | 4:2 5:2 4:2 3:2 | 2:4 3:4 | 2:2 1:2 -1:2 1:2 | 0~:8',
          D: '-:8 -:8 -:8 -:8'
        },
        form: 'AABBD' }
    ]
  }
};
