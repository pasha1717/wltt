// Fetih 1453'e özgü kontroller: her kademe kendi etkisini başlatır, sancak el değiştirince pankart çıkar,
// top gülleleri surda gedik açar, gemi gönderenle yürür ve sonunda sancak burca dikilir.
// Çekirdek testleri ayrıca çalışır. Çalıştırma: node oyunlar/fetih/test.js
'use strict';
const path = require('path');
const { OYUN_URL, CIKTI, tarayici, raporla, kontrolcu } = require(path.join(__dirname, '..', '..', 'cekirdek', 'test', 'ortak'));
const { sonuc, kontrol } = kontrolcu();

(async () => {
  const b = await tarayici();
  const hatalar = [];
  const p = await b.newPage({ viewport: { width: 1280, height: 800 } });
  p.on('pageerror', e => hatalar.push('SAYFA HATASI: ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text())) hatalar.push(m.text()); });
  await p.goto(OYUN_URL);
  await p.waitForTimeout(600);
  const bosalt = () => p.evaluate(() => { document.getElementById('bosalt').click(); });
  const O = o => p.evaluate(o2 => CanliOyun.olay(o2), o);

  await bosalt();
  await O({ tip: 'yorum', kullanici: { id: 'a', ad: 'Ali' }, metin: 'selam' });
  await O({ tip: 'yorum', kullanici: { id: 'b', ad: 'Bora' }, metin: 'selam' });
  let d = await p.evaluate(() => CanliOyun.durum());
  kontrol('Durumda sancaktar var', d.sancaktar === 'Ali', d.sancaktar);
  await O({ tip: 'hediye', kullanici: { id: 'b', ad: 'Bora' }, jeton: 5 });
  const pk = await p.evaluate(() => document.getElementById('pankart-yeri').textContent);
  kontrol('Sancak el değiştirince pankart yeni sancaktarı yazar', /Sancak yeni elde/.test(pk) && pk.includes('Bora'), pk);

  await bosalt();
  const kd = await p.evaluate(() => {
    const D = CanliOyun._test.D, cik = {};
    for (const j of [1, 9, 10, 49, 50, 199, 200, 999, 1000]) {
      CanliOyun._test.zamanEkle(0.2);
      D.mehterBit = -1;
      D.oklar.length = 0;
      D.gulle.length = 0;
      if (D.gemi) { D.gemi.k.yildiz = false; D.gemi = null; }
      CanliOyun.olay({ tip: 'hediye', kullanici: { id: 'kd' + j, ad: 'kd' + j }, jeton: j });
      const k = D.oy.get('kd' + j), B = CanliOyun.durum().vurus;
      cik[j] = { zipla: k.zip1 > k.zip0, mehter: D.mehterBit > B, ok: D.oklar.length > 0, top: D.gulle.length > 0, gemi: !!D.gemi && D.gemi.k === k };
    }
    return cik;
  });
  const bekle = (j, mehter, ok, top, gemi) => kd[j].zipla && kd[j].mehter === mehter && kd[j].ok === ok && kd[j].top === top && kd[j].gemi === gemi;
  kontrol('1–9 jeton: nara, gönderen zıplar', bekle(1, false, false, false, false) && bekle(9, false, false, false, false), [kd[1], kd[9]]);
  kontrol('10–49 jeton: mehter yürüyüşü', bekle(10, true, false, false, false) && bekle(49, true, false, false, false), [kd[10], kd[49]]);
  kontrol('50–199 jeton: ok yağmuru', bekle(50, false, true, false, false) && bekle(199, false, true, false, false), [kd[50], kd[199]]);
  kontrol('200–999 jeton: Şahi topu ateşlenir', bekle(200, false, false, true, false) && bekle(999, false, false, true, false), [kd[200], kd[999]]);
  kontrol('1000+ jeton: gemi karadan yürür, gönderen güvertede', bekle(1000, true, false, false, true), kd[1000]);
  await p.waitForTimeout(1500);
  d = await p.evaluate(() => { const D = CanliOyun._test.D, k = D.oy.get('kd1000'); return { y0: +k.y0.toFixed(2), gemi: CanliOyun.durum().gemi }; });
  kontrol('Gemideki güvertenin üstünde durur', d.gemi === 'kd1000' && d.y0 > 0.8, d);
  await p.locator('#sahne').screenshot({ path: CIKTI + '/f-gemi.png' });

  // dört gülle surda gedik açar, sancak burca dikilir
  await bosalt();
  await O({ tip: 'yorum', kullanici: { id: 'a', ad: 'Ali' }, metin: 'selam' });
  const gd = await p.evaluate(async () => {
    const D = CanliOyun._test.D;
    for (let i = 0; i < 4; i++) CanliOyun.olay({ tip: 'hediye', kullanici: { id: 'a', ad: 'Ali' }, jeton: 200 });
    await new Promise(r => setTimeout(r, 2200));
    return { hasar: D.hasar, gedik: D.gedik.length, fetih: CanliOyun.durum().fetih, pankart: document.getElementById('pankart-yeri').textContent };
  });
  kontrol('Dört gülle surda gedik açar, sancak burca dikilir', gd.hasar >= 1 && gd.gedik === 4 && gd.fetih && /gedik/.test(gd.pankart), gd);
  await p.locator('#sahne').screenshot({ path: CIKTI + '/f-fetih.png' });
  kontrol('Sayfada hata yok', hatalar.length === 0, hatalar);
  await b.close();
  process.exit(raporla(sonuc) ? 1 : 0);
})().catch(e => { console.error('TEST ÇÖKTÜ', e); process.exit(1); });
