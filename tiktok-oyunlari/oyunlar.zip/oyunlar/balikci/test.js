// Rast Gele!'ye özgü kontroller: her kademe kendi balığını ve etkisini başlatır, reis el değiştirince pankart çıkar.
// Çekirdek testleri ayrıca çalışır. Çalıştırma: node oyunlar/balikci/test.js
'use strict';
const path = require('path');
const { OYUN_URL, CIKTI, tarayici, raporla, kontrolcu } = require(path.join(__dirname, '..', '..', 'cekirdek', 'test', 'ortak'));
const { sonuc, kontrol } = kontrolcu();

(async () => {
  const b = await tarayici();
  const hatalar = [];
  const p = await b.newPage({ viewport: { width: 1280, height: 800 } });
  p.on('pageerror', e => hatalar.push('SAYFA HATASI: ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text())) hatalar.push(m.text()); });
  await p.goto(OYUN_URL);
  await p.waitForTimeout(600);
  const bosalt = () => p.evaluate(() => { document.getElementById('bosalt').click(); });
  const O = o => p.evaluate(o2 => CanliOyun.olay(o2), o);

  await bosalt();
  await O({ tip: 'yorum', kullanici: { id: 'a', ad: 'Ali' }, metin: 'rast gele' });
  await O({ tip: 'yorum', kullanici: { id: 'b', ad: 'Bora' }, metin: 'selam' });
  let d = await p.evaluate(() => CanliOyun.durum());
  kontrol('Durumda reisin adı var', d.reis === 'Ali', d.reis);
  await O({ tip: 'hediye', kullanici: { id: 'b', ad: 'Bora' }, jeton: 5 });
  const pk = await p.evaluate(() => document.getElementById('pankart-yeri').textContent);
  kontrol('Reis el değiştirince pankart yeni reisi yazar', /Yeni reis/.test(pk) && pk.includes('Bora'), pk);

  await bosalt();
  const kd = await p.evaluate(() => {
    const D = CanliOyun._test.D, cik = {};
    for (const j of [1, 9, 10, 49, 50, 199, 200, 999, 1000]) {
      CanliOyun._test.zamanEkle(0.2);
      D.titre = -1;
      D.suru.length = 0;
      D.dev = null;
      CanliOyun.olay({ tip: 'hediye', kullanici: { id: 'kd' + j, ad: 'kd' + j }, jeton: j });
      const k = D.oy.get('kd' + j), B = CanliOyun.durum().vurus;
      cik[j] = { av: k.av && k.av.tip, titre: D.titre > B, suru: D.suru.length, dev: !!D.dev && D.dev.k === k };
    }
    return cik;
  });
  const bekle = (j, av, titre, suru, dev) => kd[j].av === av && kd[j].titre === titre && (kd[j].suru > 0) === suru && kd[j].dev === dev;
  kontrol('1–9 jeton: istavrit vurur', bekle(1, 'istavrit', false, false, false) && bekle(9, 'istavrit', false, false, false), [kd[1], kd[9]]);
  kontrol('10–49 jeton: çipura vurur', bekle(10, 'cipura', false, false, false) && bekle(49, 'cipura', false, false, false), [kd[10], kd[49]]);
  kontrol('50–199 jeton: levrek, herkesin oltası titrer', bekle(50, 'levrek', true, false, false) && bekle(199, 'levrek', true, false, false), [kd[50], kd[199]]);
  kontrol('200–999 jeton: lüfer ve sürü', bekle(200, 'lufer', false, true, false) && bekle(999, 'lufer', false, true, false), [kd[200], kd[999]]);
  kontrol('1000+ jeton: dev orkinos, gönderen öne çıkar', bekle(1000, 'orkinos', false, false, true), kd[1000]);
  await p.waitForTimeout(1200);
  d = await p.evaluate(() => { const D = CanliOyun._test.D, k = D.oy.get('kd1000'); return { z: k.hedefZ, yildiz: k.yildiz }; });
  kontrol('Dev orkinosu çeken en öne yerleşir', d.yildiz && d.z < -1.5, d);
  await p.locator('#sahne').screenshot({ path: CIKTI + '/b-orkinos.png' });
  kontrol('Sayfada hata yok', hatalar.length === 0, hatalar);
  await b.close();
  process.exit(raporla(sonuc) ? 1 : 0);
})().catch(e => { console.error('TEST ÇÖKTÜ', e); process.exit(1); });
