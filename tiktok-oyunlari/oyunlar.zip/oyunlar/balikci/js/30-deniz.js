/* DENİZ — gün batımı göğü, deniz, güneşin sudaki yansıması, dalgalar, iskele, fenerler ve martılar. */

const BK_TAHTA = '#c98f4e', BK_TAHTA2 = '#a8723a', BK_TAHTA_YAN = '#6e4524';

function oyunZemin() {
  const u = gokCiz({ gok: ['#2b2f6b', '#8e4f8a', '#f08a5d', '#ffc98a'], zemin: ['#2b5f8a', '#173a5e'], pus: '#ffd9a8', gunes: { x: 0.62, r: 46, renk: '#ffe6a6', isik: '#ffb35c' } });
  bkDeniz(u);
  bkMartilar(u);
  bkIskele();
  for (const k of D.oy.values())
    golge(k.x, k.z, 0.25 * k.g.boy, 0.13 * k.g.boy);
  if (D.lider) {
    const g = pr([D.lider.x, 0, D.lider.z]);
    if (g.ok) {
      const n = 1 + 0.08 * Math.sin(B * TAU);
      c.strokeStyle = RENK.vurgu;
      c.lineWidth = Math.max(2, g.s * 0.03);
      c.beginPath();
      c.ellipse(g.x, g.y, 0.4 * g.s * n, 0.2 * g.s * n, 0, 0, TAU);
      c.stroke();
    }
  }
}
// Güneşin sudaki altın yolu ve vuruşla kayan dalga çizgileri.
function bkDeniz(u) {
  if (u >= GH)
    return;
  const gx = 0.62 * GW, y0 = Math.max(0, u);
  c.save();
  c.beginPath();
  c.rect(0, y0, GW, GH - y0);
  c.clip();
  const yol = c.createLinearGradient(0, y0, 0, GH);
  yol.addColorStop(0, 'rgba(255,214,140,0.85)');
  yol.addColorStop(1, 'rgba(255,170,90,0)');
  c.fillStyle = yol;
  for (let i = 0; i < 26; i++) {
    const t = i / 26, y = y0 + Math.pow(t, 1.6) * (GH - y0) * 0.9, w = 18 + t * 150, kay = Math.sin(TAU * (B / 4 + i * 0.37)) * w * 0.25;
    c.globalAlpha = 0.55 * (1 - t);
    c.fillRect(gx - w / 2 + kay, y, w, 2 + t * 6);
  }
  c.globalAlpha = 1;
  c.strokeStyle = 'rgba(190,225,255,0.22)';
  c.lineWidth = 1.5;
  for (let i = 0; i < 20; i++) {
    const t = ((i / 20) + (B / 16)) % 1, y = y0 + Math.pow(t, 1.8) * (GH - y0), w = 30 + t * 110;
    for (let j = 0; j < 4; j++) {
      const x = ((ozet('d' + i + j) % 1000) / 1000) * GW;
      c.beginPath();
      c.moveTo(x - w / 2, y);
      c.quadraticCurveTo(x, y - 3 - t * 5, x + w / 2, y);
      c.stroke();
    }
  }
  c.restore();
}
// Ufkun üstünde süzülen martılar.
function bkMartilar(u) {
  if (u <= 40)
    return;
  c.strokeStyle = '#2a2140';
  c.lineWidth = 2.2;
  c.lineCap = 'round';
  for (let i = 0; i < 4; i++) {
    const t = ((B / 24 + i * 0.27) % 1), x = -40 + t * (GW + 80), y = u - 120 - i * 38 + Math.sin(TAU * (B / 6 + i)) * 10;
    const kanat = 9 + 4 * Math.sin(TAU * (B + i * 0.3)), a = 14 - i * 2;
    c.beginPath();
    c.moveTo(x - a, y - kanat * 0.6);
    c.quadraticCurveTo(x - a * 0.4, y - kanat, x, y);
    c.quadraticCurveTo(x + a * 0.4, y - kanat, x + a, y - kanat * 0.6);
    c.stroke();
  }
}
// İskele: kameraya doğru uzanan tahta güverte, ön yüzü ve suya inen kazıklar.
function bkIskele() {
  const W = bkIskeleYari(), zOn = BK_ON, zUc = 40;
  const a = pr([-W, 0, zOn]), b = pr([W, 0, zOn]), cc = pr([W, 0, zUc]), d = pr([-W, 0, zUc]);
  if (!a.ok || !b.ok)
    return;
  // ön yüz ve kazıklar
  const a2 = pr([-W, BK_SU + 0.05, zOn]), b2 = pr([W, BK_SU + 0.05, zOn]);
  for (let x = -W + 0.25; x <= W - 0.2; x += Math.max(0.9, W / 3)) {
    const k1 = pr([x, -0.1, zOn + 0.08]), k2 = pr([x, BK_SU - 0.25, zOn + 0.08]);
    if (k1.ok && k2.ok) {
      kapsulCiz(k1, 0.09, k2, 0.09, BK_TAHTA_YAN, Math.max(1, k1.s * 0.01));
    }
  }
  c.lineWidth = Math.max(1, a.s * 0.01);
  c.strokeStyle = MUREKKEP;
  c.fillStyle = BK_TAHTA_YAN;
  c.beginPath();
  c.moveTo(a.x, a.y);
  c.lineTo(b.x, b.y);
  c.lineTo(b2.x, b2.y);
  c.lineTo(a2.x, a2.y);
  c.closePath();
  c.fill();
  c.stroke();
  // güverte
  c.fillStyle = BK_TAHTA;
  c.beginPath();
  c.moveTo(a.x, a.y);
  c.lineTo(b.x, b.y);
  c.lineTo(cc.x, cc.y);
  c.lineTo(d.x, d.y);
  c.closePath();
  c.fill();
  c.stroke();
  // tahta aralıkları: yakında sık, uzakta seyrek çizilir
  c.strokeStyle = BK_TAHTA2;
  for (let z = zOn + 0.32, i = 0; z < 18; z += 0.32 * (1 + Math.max(0, z) * 0.08), i++) {
    const p = pr([-W, 0, z]), q = pr([W, 0, z]);
    if (!p.ok || !q.ok)
      continue;
    c.lineWidth = Math.max(0.6, p.s * 0.012);
    c.beginPath();
    c.moveTo(p.x, p.y);
    c.lineTo(q.x, q.y);
    c.stroke();
  }
  // kenar kirişleri
  c.strokeStyle = BK_TAHTA_YAN;
  c.lineWidth = Math.max(1.5, a.s * 0.04);
  for (const [p, q] of [[a, d], [b, cc]]) {
    c.beginPath();
    c.moveTo(p.x, p.y);
    c.lineTo(q.x, q.y);
    c.stroke();
  }
}
// Derinliğe göre sıralanması gereken dekor: iskelenin ön köşelerinde fenerler.
function bkDekorEkle() {
  const W = bkIskeleYari();
  for (const s of [-1, 1]) {
    const x = s * (W - 0.12), z = BK_ON + 0.12, alt = pr([x, 0, z]), ust = pr([x, 1.75, z]);
    if (!alt.ok || !ust.ok)
      continue;
    const isik = 0.6 + 0.4 * calgi.dumP;
    ozel(alt.d - 0.01, () => {
      kapsulCiz(alt, 0.045, ust, 0.035, '#3a2a22', Math.max(1, alt.s * 0.01));
      c.globalAlpha = 0.22 * isik;
      c.fillStyle = '#ffd27a';
      c.beginPath();
      c.arc(ust.x, ust.y, 0.24 * ust.s, 0, TAU);
      c.fill();
      c.globalAlpha = 1;
      daireCiz(ust, 0.1, renkKat('#ffcf6b', '#fff6d8', isik * 0.6), Math.max(1, ust.s * 0.01));
    });
  }
}
