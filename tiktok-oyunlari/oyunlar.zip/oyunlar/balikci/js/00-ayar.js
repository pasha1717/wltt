/* AYAR — Rast Gele! oyununun bütün yazıları, hediye kademeleri, açılış kalabalığı ve sahte yorumları.
 * Derlemede HER ZAMAN İLK dosyadır; çekirdek OYUN'u buradan okur (docs/KANCALAR.md).
 * Oyun: gün batımında bir iskele. Yorum yazan iskeleye gelir, oltasını denize atar. Hediye atanın oltasına
 * balık vurur; hediye büyüdükçe balık büyür. En çok hediye atan "reis" olur: kaptan şapkası onda, iskelenin
 * ucunda durur. En büyük hediyede dev bir orkinos denizden fırlar, sahne gönderenin olur.
 */
const OYUN = {
  id: 'balikci',
  ad: 'Rast Gele!',
  logo: ['Rast', 'Gele!'],
  nasil: { yorum: 'Yorum: olta at', begeni: 'Beğeni: bereket', hediye: 'Hediye: balık vurur' },
  yazi: {
    sira: 'Reis sırası', gosterge: 'Bereket', bos: 'İskele boş. İlk oltayı atan reis olur.',
    birim: 'balıkçı', ses: 'Müziği başlat', sahne: 'Balıkçı iskelesi sahnesi', giris: 'oltasını atar',
    bosalt: 'İskeleyi boşalt'
  },
  kapasite: 30,
  // Büyükten küçüğe. Her hediyede gönderenin oltasına balık vurur; tip balığın cinsini ve ek etkiyi seçer.
  kademe: [
    { min: 1000, ad: 'Dev orkinos', tip: 'orkinos', etki: 'Dev orkinos denizden fırlar; gönderen öne çıkar, sahne onun' },
    { min: 200, ad: 'Lüfer sürüsü', tip: 'lufer', etki: 'Sürü sudan sıçrar, gönderen lüferi çeker' },
    { min: 50, ad: 'Levrek', tip: 'levrek', etki: 'Gönderen iri levreği çeker, herkesin oltası titrer' },
    { min: 10, ad: 'Çipura', tip: 'cipura', etki: 'Gönderen çipura çeker, su sıçrar' },
    { min: 1, ad: 'İstavrit', tip: 'istavrit', etki: 'Gönderenin oltasına istavrit vurur' }
  ],
  tohum: [['kaptan_rıza', 320], ['zeyno.47', 140], ['olta_ayşe', 60], ['hamsi.cemo', 25], ['elif_naz', 10], ['hasan.usta', 5], ['pınar_34', 0], ['deniz.yıldızı', 0], ['mert.can.21', 0]],
  sahteAd: ['kaptan_rıza', 'olta_ayşe', 'hamsi.cemo', 'lüfer_avcısı', 'zeyno.47', 'elif_naz', 'hasan.usta', 'pınar_34', 'deniz.yıldızı', 'mert.can.21', 'karadenizli.cemo', 'sibel_abla', 'ozan_dayı', 'egeli_duru', 'martı_mehmet', 'iskele_kemal', 'yusuf.63', 'nazlı_can', 'şahin_k', 'melo.27', 'poyraz_efe', 'sude_nur', 'baran.21', 'laz_ziya', 'muhtar_emmi', 'kumsal.ipek', 'midye_tayfun', 'çapari_cano', 'ayten_hanım', 'rüzgar.24'],
  sahteYorum: ['rast gele!', 'vurdu vurdu', 'yem kalmadı', 'oltam takıldı', 'reis kim?', 'bugün bereketli', 'istavrit bile yok', 'çapari atın', 'lüfer geldi mi', 'ben de geldim', 'balık ekmek kimde', 'iskelede yer var mı', 'adımı gördüm', 'dev balık bekliyoruz', 'martılar geldi', 'çek çek çek'],
  // Gün batımı: turuncu gök, lacivert deniz, bal rengi iskele. Deniz koyu olduğu için panel de aynı paletle okunur.
  renk: { zemin: '#142f4d', zemin2: '#1d4a6e', zemin3: '#2a6f93', cizgi: '#3b86ad', vurgu: '#ffc94a', sicak: '#ff7a45', serin: '#3fd0c9', soluk: '#a9c9d8' },
  // Alçak, geniş açılı kamera: ufuk ve gün batımı görünsün. ustPay en arkadakinin başı ve adı için pay.
  kamera: { egim: 0.5, F: 700, enYakin: 3.5, ustPay: 1.5, altPay: 0.1 },
  etiket: { ustSinir: true, altSinir: true, disari: 'gizle', balonSira: 'derinlik' },
  sahneYazi: { pankart: 'alt' },
  // Takım: düğün takımı (darbuka, def, klarnet); kıyı kasabasının akşamı. İki özgün hava.
  muzik: {
    takim: 'dugun',
    havalar: [
      { id: 'poyraz', ad: 'Poyraz', bpm: 100, spb: 4, bar: 16, tonik: 293.7,
        dizi: [0, 150, 300, 500, 700, 800, 1000],                       // uşşak
        davul: { ana: 'D...k.T.D.k.T.k.', cesni: 'D.k.k.T.D.kkT.kr', gecis: 'D.k.TrT.D.krTkTr' },
        ust: { ana: '....z.......z...', cesni: '....z...z...z...', gecis: '..z.z.z.z.z.z.zz' },
        bas: { ana: '1.......5.......', cesni: '1.......5...3...', gecis: '1...5...8...5...' },
        bolum: {
          A: '0:2 2:2 3:2 4:2 5:4 4:2 3:2 | 4:2 5:2 6:2 5:2 4:4 3:4 | 2:2 3:2 4:2 3:2 2:2 1:2 2:4 | 1:2 0:2 1:2 2:2 0:8',
          B: "7:4 6:2 5:2 6:4 7:2 8':2 | 7:2 6:2 5:2 4:2 5:8 | 4:2 5:2 4:2 3:2 2:4 3:2 4:2 | 2:2 1:2 0:4 0~:8",
          D: '-:16 -:16'
        },
        eslik: { A: '0:16 3:16 0:16 4:16', B: '0:16 4:16 3:16 0:16' },
        form: 'AABBD' },
      { id: 'lodos', ad: 'Lodos', bpm: 116, spb: 4, bar: 8, tonik: 329.6,
        dizi: [0, 100, 300, 500, 700, 800, 1000],                       // kürdi
        davul: { ana: 'D.kTD.T.', cesni: 'D.kTDkTk', gecis: 'DkTkTrTr' },
        ust: { ana: '..z...z.', cesni: '..z.z.z.', gecis: 'z.z.zzzz' },
        bas: { ana: '1...5...', cesni: '1...5.8.', gecis: '1.5.8.5.' },
        bolum: {
          A: '4:2 3:1 2:1 3:2 4:2 | 5:4 4:2 3:2 | 2:2 1:2 2:2 3:2 | 1:4 0:4 | 4:2 5:1 6:1 7:2 6:2 | 5:2 4:2 3:4 | 2:1 3:1 2:1 1:1 0:2 1:2 | 0:8',
          B: "7:2 8:2 7:2 6:2 | 5:4 6:2 5:2 | 4:2 5:2 4:2 3:2 | 4:4 -:4 | 3':2 4:2 3:2 2:2 | 1:2 2:2 3:4 | 2:2 1:2 -1:2 1:2 | 0~:8",
          D: '-:8 -:8 -:8 -:8'
        },
        eslik: { A: '0:16 3:16 0:16 4:8 0:8', B: '0:16 3:16 4:16 0:16' },
        form: 'AABBD' }
    ]
  }
};
