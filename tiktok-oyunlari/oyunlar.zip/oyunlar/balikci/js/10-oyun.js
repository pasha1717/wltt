/* RAST GELE! — yerleşim, olaylar, hareket ve izleyicilerin çizimi.
 *
 * İskele kameraya doğru uzanır; izleyiciler iskelenin ucunda sıra sıra durur, kameraya (denize) bakar ve
 * oltalarını önlerindeki suya atar. Reis (lider) en önde, ortada, kaptan şapkalıdır. Hediye atanın oltasına
 * balık vurur (20-balik.js). Deniz, gök ve iskele 30-deniz.js'te.
 */

/* ---- yerleşim ---- */
const BK_SIRA = 6;        // bir sırada kaç kişi
const BK_ARA_X = 0.82;    // yan yana iki kişi arası (metre)
const BK_ARA_Z = 0.95;    // iki sıra arası
const BK_REIS_Z = -1.35;  // reis bu kadar önde durur
const BK_YILDIZ_Z = -1.85; // dev orkinosu çeken, reisin de önüne çıkar
const BK_ON = -2.35;      // iskelenin ön kenarı
const BK_SU = -0.42;      // su yüzeyinin yüksekliği (iskele güvertesi 0)

Object.assign(D, { avlar: 0, sicrama: [], suru: [], dev: null, sovBit: -1, titre: -1 });

function bkHazir(k) {
  if (k.bk)
    return;
  const h = ozet(k.id);
  // şamandıranın iskeleden uzaklığı ve küçük salınım evresi kişiye özgü: aynı kişi hep aynı yere atar
  k.bk = { uzak: 0.4 + (h % 4) * 0.16, evre: (h % 97) / 97, egik: 0, tepe: [0, 0, 0], sam: [0, 0, 0], el: [0, 0, 0] };
  k.av = null;
}
function oyunYerlesim() {
  const yildiz = D.dev && D.dev.k && D.oy.has(D.dev.k.id) ? D.dev.k : null;
  let i = 0;
  for (const k of D.sira) {
    bkHazir(k);
    if (k === yildiz) {
      k.hedefX = 0;
      k.hedefZ = BK_YILDIZ_Z;
      continue;
    }
    if (i === 0) {
      // yıldız sahnedeyken reis yana kayar ki ikisinin de yüzü görünsün
      k.hedefX = yildiz ? 0.95 : 0;
      k.hedefZ = BK_REIS_Z;
      i++;
      continue;
    }
    const j = i - 1, s = Math.floor(j / BK_SIRA), kalan = D.sira.length - 1 - (yildiz ? 1 : 0) - s * BK_SIRA;
    const n = Math.min(BK_SIRA, kalan), yer = j % BK_SIRA;
    k.hedefX = (yer - (n - 1) / 2) * BK_ARA_X + (s % 2 ? BK_ARA_X / 2 : 0);
    k.hedefZ = -0.35 + s * BK_ARA_Z;
    i++;
  }
}
// iskelenin genişliği: en dıştaki balıkçıdan biraz geniş
function bkIskeleYari() {
  let m = 1.6;
  for (const k of D.sira)
    m = Math.max(m, Math.abs(k.hedefX) + 0.75);
  return m;
}
function oyunGiris(k) {
  bkHazir(k);
  // iskelenin arkasından, yürüyerek gelir
  k.x = k.hedefX * 0.6;
  k.z = k.hedefZ + 7;
}
function oyunBaslat() {
  for (const k of D.sira) {
    bkHazir(k);
    k.x = k.hedefX;
    k.z = k.hedefZ;
    k.yer = 1;
    k.yon = Math.PI;
    k.yeni = -9;
  }
}
function oyunBosalt() {
  D.avlar = 0;
  D.sicrama.length = 0;
  D.suru.length = 0;
  D.dev = null;
  D.sovBit = -1;
  D.titre = -1;
  muzik.sov = false;
}

/* ---- olaylar ---- */
function oyunHediye(k, jeton, kademe) {
  bkHazir(k);
  const tip = kademe.tip;
  bkAvBaslat(k, tip);
  if (tip === 'levrek')
    D.titre = B + 2;
  else if (tip === 'lufer') {
    bkSuruBaslat();
    D.sarsinti = 0.4;
    konfeti(40, 0.6);
  }
  else if (tip === 'orkinos') {
    D.dev = { b0: B, k };
    D.sovBit = B + 14;
    muzik.sov = true;
    k.yildiz = true;
    D.sarsinti = 0.8;
    pankart('Dev orkinos!', k.ad);
  }
}
function oyunLiderDegisti(eski, yeni) {
  // dev orkinosla reis olanın pankartı ikisini birden söyler, biri öbürünü silmesin
  pankart(D.dev && D.dev.k === yeni ? 'Dev orkinos! Yeni reis' : 'Yeni reis', yeni.ad);
  konfeti(60, 0.8);
}

/* ---- her kare ---- */
function oyunGuncelle(dt) {
  muzik.sov = B < D.sovBit;
  if (D.dev && B > D.sovBit) {
    const k = D.dev.k;
    k.yildiz = false;
    D.dev = null;
    oyunYerlesim();
  }
  bkSuGuncelle();
  for (const k of D.oy.values()) {
    bkHazir(k);
    const hx = k.cikiyor ? k.x * 0.6 : k.hedefX, hz = k.cikiyor ? 9 : k.hedefZ;
    const dx = hx - k.x, dz = hz - k.z, uz = Math.hypot(dx, dz);
    if (uz > 0.002) {
      const adim = Math.min(uz, (2.2 + uz * 1.2) * dt);
      k.x += dx / uz * adim;
      k.z += dz / uz * adim;
    }
    k.yer += ((uz < 0.16 && !k.cikiyor ? 1 : 0) - k.yer) * Math.min(1, dt * 7);
    if (k.cikiyor)
      k.gitti = k.z > 8.5;
    const bak = uz > 0.3 ? Math.atan2(dx, dz) : Math.PI;
    k.yon += aciFark(k.yon, bak) * Math.min(1, dt * 8);
    k.basOlcek = k === D.lider ? 1.18 : undefined;
    bkPoz(k);
  }
}
// Olta tutan poz: iki el önde, olta sağ yandan denize uzanır. Balık vurunca olta eğilir, kişi geriye yaslanır.
function bkPoz(k) {
  const b = k.bk, av = bkAvDurum(k);
  const titre = B < D.titre ? 0.25 * Math.abs(Math.sin(TAU * 2 * (B + b.evre))) : 0;
  b.egik += ((av ? av.egik : 0) + titre - b.egik) * 0.25;
  const poz = pozBekle(k);
  poz.egim -= b.egik * 0.12;
  const W = iskeletKur(k, poz), e = b.egik, hy = poz.hipY;
  k.j.haL = W(-0.04, hy + 0.14 + e * 0.05, 0.16);
  k.j.haR = W(-0.17, hy + 0.3 + e * 0.12, 0.27);
  k.elSekil = { R: 'yumruk', L: 'yumruk' };
  kolKur(k);
  const dip = W(0.02, hy + 0.04, 0.06), tepe = W(-0.62, hy + 1.3 - e * 0.55, 1.0 + e * 0.25);
  b.dip = dip;
  b.tepe = tepe;
  // şamandıra: oltanın ucunun altında, iskelenin önündeki suda
  const sz = Math.min(BK_ON - b.uzak, tepe[2] - 0.4), bob = 0.025 * Math.sin(TAU * (B / 2 + b.evre));
  b.sam = [tepe[0] * 1.05, BK_SU + bob - (av ? av.dal : 0), sz];
}
function oyunKamera() {
  const n = [[1.4, BK_ON - 1.15], [-1.4, BK_ON - 1.15], [1.4, 0], [-1.4, 0]];
  for (const k of D.sira)
    n.push([k.hedefX, k.hedefZ]);
  return n;
}
function oyunCiz() {
  for (const k of D.oy.values()) {
    if (!insanEkle(k))
      continue;
    const z = k.hedefZ;
    // ön sıradakinin adı çenesinin altına asılır ki arkadakinin yüzünü örtmesin
    if (z < 0 && k !== D.lider && !k.yildiz)
      k.et.asagi = true;
    bkOltaEkle(k);
    if (k === D.lider)
      bkSapkaEkle(k);
  }
  bkSuEkle();
  bkDekorEkle();
}
function oyunDurum(d) {
  d.reis = D.lider ? D.lider.ad : null;
  d.avlar = D.avlar;
  d.dev = !!D.dev;
}
