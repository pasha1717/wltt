/* BALIK — oltaya vuran balık, sudan sıçrayan sürü, dev orkinos, su sıçramaları; olta, şamandıra ve kaptan şapkası.
 * Bütün süreler vuruşla (B) ölçülür.
 */

// Cinslere göre boy (metre), renkler ve oltada kalma süresi (vuruş).
const BK_BALIK = {
  istavrit: { boy: 0.26, sirt: '#4f7f9e', karin: '#dfe9ee', sure: 5 },
  cipura: { boy: 0.36, sirt: '#8d98a3', karin: '#f1f2ea', serit: '#f0b93a', sure: 5.5 },
  levrek: { boy: 0.52, sirt: '#56717d', karin: '#e2e9e8', sure: 6 },
  lufer: { boy: 0.56, sirt: '#3f7a8f', karin: '#d3e3e5', sure: 6 },
  orkinos: { boy: 1.05, sirt: '#24406e', karin: '#d6dfea', serit: '#f2c94c', sure: 14 }
};

function bkAvBaslat(k, tip) {
  const t = BK_BALIK[tip] || BK_BALIK.istavrit;
  k.av = { tip, b0: B, boy: t.boy, sure: t.sure, cikti: false };
  D.avlar++;
}
// Avın o anki evresi: olta ne kadar eğik, şamandıra ne kadar dalmış, balık sudan çıktı mı.
function bkAvDurum(k) {
  const av = k.av;
  if (!av)
    return null;
  const t = B - av.b0;
  if (t > av.sure || t < 0) {
    k.av = null;
    return null;
  }
  const g = clamp(av.boy / 0.5, 0.6, 1.5);
  if (t < 1)
    return { t, egik: t * 0.6 * g, dal: 0.09 * Math.abs(Math.sin(Math.PI * t * 2)) };
  if (t < 2.2)
    return { t, egik: (0.6 - 0.25 * (t - 1) / 1.2) * g, dal: 0 };
  return { t, egik: (0.35 + 0.05 * Math.sin(TAU * B)) * g, dal: 0 };
}

/* ---- sürü, dev, sıçrama ---- */
function bkSuruBaslat() {
  const W = bkIskeleYari() + 1.4;
  for (let i = 0; i < 14; i++)
    D.suru.push({ x0: -W + Math.random() * 2 * W, z: BK_ON - 0.8 - Math.random() * 1.7, b0: B + i * 0.17 + Math.random() * 0.2,
      yon: Math.random() < 0.5 ? -1 : 1, h: 0.45 + Math.random() * 0.6, boy: 0.3 + Math.random() * 0.16, gir: false, cik: false });
}
function bkSicra(x, z, r) {
  if (D.sicrama.length < 40)
    D.sicrama.push({ x, z, r, b0: B });
}
const BK_SURU_SURE = 1.3, BK_DEV_SURE = 3.4;
function bkSuGuncelle() {
  for (let i = D.sicrama.length - 1; i >= 0; i--)
    if (B - D.sicrama[i].b0 > 1.6 || B < D.sicrama[i].b0)
      D.sicrama.splice(i, 1);
  for (let i = D.suru.length - 1; i >= 0; i--) {
    const f = D.suru[i], u = (B - f.b0) / BK_SURU_SURE;
    if (u >= 0 && !f.cik) {
      f.cik = true;
      bkSicra(f.x0, f.z, 0.25);
    }
    if (u >= 1) {
      bkSicra(f.x0 + f.yon, f.z, 0.25);
      D.suru.splice(i, 1);
    }
  }
  const d = D.dev;
  if (d) {
    const u = (B - d.b0) / BK_DEV_SURE;
    if (!d.cikti && u >= 0) {
      d.cikti = true;
      bkSicra(-3.2, BK_ON - 2.6, 1.1);
    }
    if (!d.dustu && u >= 1) {
      d.dustu = true;
      bkSicra(3.2, BK_ON - 2.6, 1.3);
      D.sarsinti = 0.6;
      konfeti(80, 0.9);
    }
  }
}

/* ---- çizim ---- */
// Balık: L ekranda boyu (piksel), aci gövdenin yönü (0 sağa bakar). Ağzı +x ucunda.
function bkBalikCiz(x, y, L, aci, t, ayna) {
  c.save();
  c.translate(x, y);
  c.rotate(aci);
  if (ayna)
    c.scale(1, -1); // sola giden balık sırtüstü dönmesin
  c.lineWidth = Math.max(1, L * 0.035);
  c.strokeStyle = MUREKKEP;
  const H = L * 0.21;
  // kuyruk
  c.fillStyle = t.sirt;
  c.beginPath();
  c.moveTo(-L * 0.38, 0);
  c.lineTo(-L * 0.56, -H * 1.1);
  c.quadraticCurveTo(-L * 0.48, 0, -L * 0.56, H * 1.1);
  c.closePath();
  c.fill();
  c.stroke();
  // gövde: sırt koyu, karın açık
  c.beginPath();
  c.ellipse(0, 0, L * 0.42, H, 0, 0, TAU);
  c.fillStyle = t.karin;
  c.fill();
  c.save();
  c.clip();
  c.fillStyle = t.sirt;
  c.beginPath();
  c.ellipse(0, -H * 0.55, L * 0.46, H * 0.85, 0, 0, TAU);
  c.fill();
  if (t.serit) {
    c.fillStyle = t.serit;
    c.fillRect(L * 0.12, -H, L * 0.05, H * 2);
  }
  c.restore();
  c.beginPath();
  c.ellipse(0, 0, L * 0.42, H, 0, 0, TAU);
  c.stroke();
  // sırt yüzgeci
  c.fillStyle = t.sirt;
  c.beginPath();
  c.moveTo(-L * 0.12, -H * 0.9);
  c.lineTo(-L * 0.02, -H * 1.55);
  c.lineTo(L * 0.1, -H * 0.92);
  c.fill();
  c.stroke();
  // göz
  c.fillStyle = '#fff';
  c.beginPath();
  c.arc(L * 0.27, -H * 0.2, H * 0.28, 0, TAU);
  c.fill();
  c.stroke();
  c.fillStyle = MUREKKEP;
  c.beginPath();
  c.arc(L * 0.29, -H * 0.2, H * 0.13, 0, TAU);
  c.fill();
  c.restore();
}
// Olta, misina, şamandıra ve vuran balık: tek parça, elin önünde çizilir.
function bkOltaEkle(k) {
  const b = k.bk, ha = k.p.haR;
  if (!b.dip || !ha || !ha.ok)
    return;
  const p0 = pr(b.dip), p1 = pr(b.tepe);
  if (!p0.ok || !p1.ok)
    return;
  const av = k.av ? bkAvDurum(k) : null, reis = k === D.lider;
  let balik = null;
  if (av && av.t >= 1) {
    const tt = BK_BALIK[k.av.tip], asili = [b.tepe[0], b.tepe[1] - 0.22 - k.av.boy * 0.5, b.tepe[2]];
    if (!k.av.cikti) {
      k.av.cikti = true;
      k.av.s0 = b.sam.slice();
      bkSicra(b.sam[0], b.sam[2], 0.2 + k.av.boy * 0.4);
    }
    let w;
    if (av.t < 2.2) {
      const u = yumusak((av.t - 1) / 1.2), s0 = k.av.s0;
      w = [lerp(s0[0], asili[0], u), lerp(s0[1], asili[1], u) + Math.sin(Math.PI * u) * 0.45, lerp(s0[2], asili[2], u)];
    }
    else
      w = [asili[0] + 0.05 * Math.sin(TAU * B * 1.5), asili[1], asili[2]];
    balik = { p: pr(w), t: tt, boy: k.av.boy, kivril: 0.35 * Math.sin(TAU * B * 2) };
  }
  const ps = pr(b.sam);
  ozel(ha.d - 0.03, () => {
    // olta: dipten uca incelen, balık vurunca eğilen çizgi
    const mx = (p0.x + p1.x) / 2, my = (p0.y + p1.y) / 2, e = b.egik;
    const nx = -(p1.y - p0.y), ny = p1.x - p0.x, nu = Math.hypot(nx, ny) || 1;
    const kx = mx + nx / nu * e * 0.12 * p1.s * (nx > 0 ? 1 : -1), ky = my + Math.abs(ny / nu) * e * 0.12 * p1.s + e * 0.06 * p1.s;
    c.lineCap = 'round';
    c.strokeStyle = MUREKKEP;
    c.lineWidth = Math.max(2, p0.s * 0.034);
    c.beginPath();
    c.moveTo(p0.x, p0.y);
    c.quadraticCurveTo(kx, ky, p1.x, p1.y);
    c.stroke();
    c.strokeStyle = reis ? '#f2c14e' : '#8a5a2b';
    c.lineWidth = Math.max(1.2, p0.s * 0.02);
    c.stroke();
    // misina: uçtan şamandıraya ya da balığın ağzına
    const hx = balik && balik.p.ok ? balik.p.x : ps.x, hy = balik && balik.p.ok ? balik.p.y - balik.boy * 0.45 * balik.p.s : ps.y;
    c.strokeStyle = 'rgba(255,255,255,0.8)';
    c.lineWidth = Math.max(1, p1.s * 0.006);
    c.beginPath();
    c.moveTo(p1.x, p1.y);
    c.quadraticCurveTo((p1.x + hx) / 2, Math.max(p1.y, hy) + (balik ? 0 : 0.08 * p1.s), hx, hy);
    c.stroke();
    // şamandıra (balık sudan çıkınca misinanın ucunda kalmaz)
    if (!balik && ps.ok) {
      const r = Math.max(2.5, 0.05 * ps.s);
      c.lineWidth = Math.max(1, r * 0.25);
      c.strokeStyle = 'rgba(255,255,255,0.45)';
      c.beginPath();
      c.ellipse(ps.x, ps.y + r * 0.6, r * (1.8 + 0.4 * Math.sin(TAU * (B / 2 + b.evre))), r * 0.5, 0, 0, TAU);
      c.stroke();
      c.strokeStyle = MUREKKEP;
      c.fillStyle = '#fff6e8';
      c.beginPath();
      c.arc(ps.x, ps.y, r, 0, TAU);
      c.fill();
      c.fillStyle = '#e8463a';
      c.beginPath();
      c.arc(ps.x, ps.y, r, Math.PI, TAU);
      c.fill();
      c.beginPath();
      c.arc(ps.x, ps.y, r, 0, TAU);
      c.stroke();
    }
    if (balik && balik.p.ok)
      bkBalikCiz(balik.p.x, balik.p.y, balik.boy * balik.p.s, -Math.PI / 2 + balik.kivril, balik.t);
  });
}
// Reisin kaptan şapkası: beyaz tepe, lacivert siper, altın arma.
function bkSapkaEkle(k) {
  const ph = k.p.kafa;
  if (!ph || !ph.ok)
    return;
  const R = KAFA_R * k.g.boy * (k.basOlcek || 1) * ph.s;
  ozel(ph.d - 0.06, () => {
    const x = ph.x, y = ph.y;
    c.lineWidth = Math.max(1, ph.s * 0.012);
    c.strokeStyle = MUREKKEP;
    c.fillStyle = '#1f2b4a';
    c.beginPath();
    c.moveTo(x - R * 0.9, y - R * 0.5);
    c.lineTo(x - R * 0.82, y - R * 0.82);
    c.lineTo(x + R * 0.82, y - R * 0.82);
    c.lineTo(x + R * 0.9, y - R * 0.5);
    c.closePath();
    c.fill();
    c.stroke();
    c.fillStyle = '#f6f2e6';
    c.beginPath();
    c.ellipse(x, y - R * 0.9, R * 1.08, R * 0.36, 0, 0, TAU);
    c.fill();
    c.stroke();
    c.fillStyle = '#141c30';
    c.beginPath();
    c.ellipse(x, y - R * 0.47, R * 0.86, R * 0.16, 0, 0, Math.PI);
    c.fill();
    c.stroke();
    c.fillStyle = RENK.vurgu;
    c.beginPath();
    c.arc(x, y - R * 0.68, R * 0.15, 0, TAU);
    c.fill();
    c.stroke();
  });
}
// Sudan sıçrayan sürü, dev orkinos ve su sıçramaları.
function bkSuEkle() {
  for (const f of D.suru) {
    const u = (B - f.b0) / BK_SURU_SURE;
    if (u < 0 || u > 1)
      continue;
    const w = [f.x0 + f.yon * u, BK_SU + f.h * Math.sin(Math.PI * u), f.z], p = pr(w);
    if (!p.ok)
      continue;
    const egim = Math.atan2(-f.h * Math.PI * Math.cos(Math.PI * u), f.yon);
    ozel(p.d, () => bkBalikCiz(p.x, p.y, f.boy * p.s, egim, BK_BALIK.lufer, f.yon < 0));
  }
  const d = D.dev;
  if (d) {
    const u = (B - d.b0) / BK_DEV_SURE;
    if (u >= 0 && u <= 1) {
      const H = 3.6, w = [-3.2 + 6.4 * u, BK_SU - 0.3 + H * Math.sin(Math.PI * u), BK_ON - 2.6], p = pr(w);
      const egim = Math.atan2(-H * Math.PI * Math.cos(Math.PI * u), 6.4);
      if (p.ok)
        ozel(p.d, () => bkBalikCiz(p.x, p.y, 2.3 * p.s, egim, BK_BALIK.orkinos));
    }
  }
  for (const s of D.sicrama) {
    const t = (B - s.b0) / 1.6, p = pr([s.x, BK_SU, s.z]);
    if (!p.ok)
      continue;
    ozel(p.d, () => {
      const r = s.r * p.s;
      c.globalAlpha = 1 - t;
      c.strokeStyle = '#e8f6ff';
      c.lineWidth = Math.max(1, r * 0.12);
      for (const k of [1, 0.6]) {
        c.beginPath();
        c.ellipse(p.x, p.y, r * (0.5 + t * 1.6) * k, r * (0.16 + t * 0.5) * k, 0, 0, TAU);
        c.stroke();
      }
      // damlalar: yukarı fırlayıp düşer
      c.fillStyle = '#f2fbff';
      for (let i = 0; i < 9; i++) {
        const a = (i / 9) * TAU, h = (1.6 + (i % 3) * 0.5) * t - 3.2 * t * t;
        if (h < 0)
          continue;
        c.beginPath();
        c.arc(p.x + Math.cos(a) * r * (0.3 + t * 1.2), p.y - h * r * 1.4, Math.max(1.5, r * 0.08), 0, TAU);
        c.fill();
      }
      c.globalAlpha = 1;
    });
  }
}
