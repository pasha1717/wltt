// Pavyon Gecesi'ne özgü kontroller: her kademe kendi etkisini başlatır, ağa el değiştirince pankart çıkar,
// en büyük hediyede gönderen sahneye çıkar. Çekirdek testleri ayrıca çalışır. Çalıştırma: node oyunlar/pavyon/test.js
'use strict';
const path = require('path');
const { OYUN_URL, CIKTI, tarayici, raporla, kontrolcu } = require(path.join(__dirname, '..', '..', 'cekirdek', 'test', 'ortak'));
const { sonuc, kontrol } = kontrolcu();

(async () => {
  const b = await tarayici();
  const hatalar = [];
  const p = await b.newPage({ viewport: { width: 1280, height: 800 } });
  p.on('pageerror', e => hatalar.push('SAYFA HATASI: ' + e.message));
  p.on('console', m => { if (m.type() === 'error' && !/ERR_TUNNEL|Failed to load resource/.test(m.text())) hatalar.push(m.text()); });
  await p.goto(OYUN_URL);
  await p.waitForTimeout(600);
  const bosalt = () => p.evaluate(() => { document.getElementById('bosalt').click(); });
  const O = o => p.evaluate(o2 => CanliOyun.olay(o2), o);

  await bosalt();
  await O({ tip: 'yorum', kullanici: { id: 'a', ad: 'Ali' }, metin: 'selam' });
  await O({ tip: 'yorum', kullanici: { id: 'b', ad: 'Bora' }, metin: 'selam' });
  let d = await p.evaluate(() => CanliOyun.durum());
  kontrol('Durumda gecenin ağası var', d.aga === 'Ali', d.aga);
  await O({ tip: 'hediye', kullanici: { id: 'b', ad: 'Bora' }, jeton: 5 });
  const pk = await p.evaluate(() => document.getElementById('pankart-yeri').textContent);
  kontrol('Ağa el değiştirince pankart yeni ağayı yazar', /Gecenin ağası/.test(pk) && pk.includes('Bora'), pk);

  await bosalt();
  const kd = await p.evaluate(() => {
    const D = CanliOyun._test.D, cik = {};
    for (const j of [1, 9, 10, 49, 50, 199, 200, 999, 1000]) {
      CanliOyun._test.zamanEkle(0.2);
      D.ucan.length = 0;
      D.yagmur.length = 0;
      D.isik = null;
      D.sov = null;
      CanliOyun.olay({ tip: 'hediye', kullanici: { id: 'kd' + j, ad: 'kd' + j }, jeton: j });
      const k = D.oy.get('kd' + j);
      const tur = {};
      for (const u of D.ucan) tur[u.tip] = (tur[u.tip] || 0) + 1;
      cik[j] = { tur, yagmur: D.yagmur.length > 0, isik: !!D.isik && D.isik.k === k, sahne: !!D.sov && D.sov.k === k };
    }
    return cik;
  });
  const bekle = (j, tip, yagmur, isik, sahne) => (kd[j].tur[tip] || 0) > 0 && kd[j].yagmur === yagmur && kd[j].isik === isik && kd[j].sahne === sahne;
  kontrol('1–9 jeton: peçete atılır', bekle(1, 'pecete', false, false, false) && bekle(9, 'pecete', false, false, false), [kd[1], kd[9]]);
  kontrol('10–49 jeton: para saçılır', bekle(10, 'para', false, false, false) && bekle(49, 'para', false, false, false), [kd[10], kd[49]]);
  kontrol('50–199 jeton: çiçek gider, ışık gönderene döner', bekle(50, 'cicek', false, true, false) && bekle(199, 'cicek', false, true, false), [kd[50], kd[199]]);
  kontrol('200–999 jeton: para yağmuru', bekle(200, 'para', true, false, false) && bekle(999, 'para', true, false, false), [kd[200], kd[999]]);
  kontrol('1000+ jeton: gönderen sahneye çıkar, ışık ve yağmur onda', bekle(1000, 'para', true, true, true), kd[1000]);
  await p.waitForTimeout(2500);
  d = await p.evaluate(() => { const D = CanliOyun._test.D, k = D.oy.get('kd1000'); return { y0: +k.y0.toFixed(2), yildiz: k.yildiz, yigin: D.yigin, sahnede: CanliOyun.durum().sahnede }; });
  kontrol('Sahneye çıkan sahnenin üstünde durur, atılan para sahnede yığılır', d.yildiz && d.y0 > 0.5 && d.yigin > 0 && d.sahnede === 'kd1000', d);
  await p.locator('#sahne').screenshot({ path: CIKTI + '/p-sahne.png' });
  kontrol('Sayfada hata yok', hatalar.length === 0, hatalar);
  await b.close();
  process.exit(raporla(sonuc) ? 1 : 0);
})().catch(e => { console.error('TEST ÇÖKTÜ', e); process.exit(1); });
