/* UÇAN — sahneye atılan peçete, para ve çiçek; sahnenin önündeki yığın; salona yağan para; ışık huzmeleri.
 * Bütün süreler vuruşla (B) ölçülür.
 */

const PV_UCUS = 1.3;  // bir atışın sahneye varması (vuruş)

// k'nin elinden sahneye adet kadar şey atar; arka arkaya, biraz dağınık.
function pvAt(k, tip, adet) {
  const el = k.j && k.j.haR ? k.j.haR : [k.x, 1, k.z];
  for (let i = 0; i < adet; i++) {
    if (D.ucan.length > 80)
      break;
    D.ucan.push({ tip, b0: B + i * 0.12, p0: [el[0], el[1] + 0.1, el[2]], hx: (Math.random() - 0.5) * 1.6, don: (Math.random() - 0.5) * 8, h: 1.1 + Math.random() * 0.5 });
  }
}
function pvYagmur(adet) {
  for (let i = 0; i < adet && D.yagmur.length < 160; i++)
    D.yagmur.push({ x: Math.random() * GW, b0: B + Math.random() * 3, hiz: 260 + Math.random() * 160, sal: Math.random() * TAU, don: (Math.random() - 0.5) * 6 });
}
function pvUcanGuncelle() {
  for (let i = D.ucan.length - 1; i >= 0; i--) {
    const u = D.ucan[i];
    if (B - u.b0 >= PV_UCUS) {
      // vardı: sahnenin önündeki yığına eklenir
      if (u.tip === 'para')
        D.yigin = Math.min(60, D.yigin + 1);
      else if (u.tip === 'cicek')
        D.cicek = Math.min(8, D.cicek + 1);
      else
        D.pecete = Math.min(40, D.pecete + 1);
      D.ucan.splice(i, 1);
    }
  }
  for (let i = D.yagmur.length - 1; i >= 0; i--)
    if (B - D.yagmur[i].b0 > 7)
      D.yagmur.splice(i, 1);
}
function pvUcanYer(u) {
  const t = clamp((B - u.b0) / PV_UCUS, 0, 1), hedef = [u.hx, PV_SAHNE_Y + 0.05, D.sahneZ + 0.25];
  return { t, w: [lerp(u.p0[0], hedef[0], t), lerp(u.p0[1], hedef[1], t) + Math.sin(Math.PI * t) * u.h, lerp(u.p0[2], hedef[2], t)] };
}

/* ---- çizim ---- */
function pvParaCiz(x, y, w, aci) {
  c.save();
  c.translate(x, y);
  c.rotate(aci);
  c.fillStyle = '#7fbf6a';
  c.strokeStyle = '#2f5a2a';
  c.lineWidth = Math.max(1, w * 0.06);
  c.fillRect(-w / 2, -w * 0.25, w, w * 0.5);
  c.strokeRect(-w / 2, -w * 0.25, w, w * 0.5);
  c.fillStyle = '#d8efc8';
  c.beginPath();
  c.arc(0, 0, w * 0.14, 0, TAU);
  c.fill();
  c.restore();
}
function pvPeceteCiz(x, y, w, aci) {
  c.save();
  c.translate(x, y);
  c.rotate(aci);
  c.fillStyle = '#fbf7ee';
  c.strokeStyle = 'rgba(40,20,40,0.5)';
  c.lineWidth = 1;
  c.beginPath();
  c.moveTo(-w / 2, -w / 2);
  c.lineTo(w / 2, -w * 0.4);
  c.lineTo(w * 0.42, w / 2);
  c.lineTo(-w * 0.45, w * 0.42);
  c.closePath();
  c.fill();
  c.stroke();
  c.restore();
}
function pvCicekCiz(x, y, w) {
  c.save();
  c.lineWidth = Math.max(1, w * 0.05);
  c.strokeStyle = MUREKKEP;
  c.fillStyle = '#3f8f4a';
  c.beginPath();
  c.moveTo(x - w * 0.12, y);
  c.lineTo(x + w * 0.12, y);
  c.lineTo(x + w * 0.04, y + w * 0.6);
  c.lineTo(x - w * 0.04, y + w * 0.6);
  c.closePath();
  c.fill();
  c.stroke();
  const renk = ['#e8364f', '#ff6f91', '#ffd166', '#e8364f', '#f6f0e6'];
  for (let i = 0; i < 5; i++) {
    const a = i / 5 * TAU;
    c.fillStyle = renk[i];
    c.beginPath();
    c.arc(x + Math.cos(a) * w * 0.2, y - w * 0.1 + Math.sin(a) * w * 0.14, w * 0.15, 0, TAU);
    c.fill();
    c.stroke();
  }
  c.restore();
}
// Havada uçanlar ve sahnenin önündeki yığın.
function pvUcanEkle() {
  for (const u of D.ucan) {
    if (B < u.b0)
      continue;
    const { t, w } = pvUcanYer(u), p = pr(w);
    if (!p.ok)
      continue;
    const aci = u.don * t;
    if (u.tip === 'para')
      ozel(p.d, () => pvParaCiz(p.x, p.y, 0.2 * p.s, aci));
    else if (u.tip === 'cicek')
      ozel(p.d, () => pvCicekCiz(p.x, p.y, 0.4 * p.s));
    else
      ozel(p.d, () => pvPeceteCiz(p.x, p.y, 0.16 * p.s, aci));
  }
  const m = pr([0, PV_SAHNE_Y, D.sahneZ + 0.25]);
  if (!m.ok || (!D.yigin && !D.pecete && !D.cicek))
    return;
  ozel(m.d - 0.02, () => {
    // yığın: kimliksiz ama hep aynı dağılım (ozet) ki kareler arasında titremesin
    for (let i = 0; i < D.pecete; i++) {
      const h = ozet('pc' + i), q = pr([((h % 1000) / 1000 - 0.5) * 3.4, PV_SAHNE_Y + 0.01, D.sahneZ + 0.12 + ((h >> 10) % 100) / 100 * 0.35]);
      if (q.ok)
        pvPeceteCiz(q.x, q.y, 0.14 * q.s, (h % 628) / 100);
    }
    for (let i = 0; i < D.yigin; i++) {
      const h = ozet('py' + i), r = Math.sqrt(i / 60);
      const q = pr([((h % 1000) / 1000 - 0.5) * (0.8 + r * 2.4), PV_SAHNE_Y + 0.01 + (i % 6) * 0.004, D.sahneZ + 0.15 + ((h >> 10) % 100) / 100 * 0.3]);
      if (q.ok)
        pvParaCiz(q.x, q.y, 0.18 * q.s, (h % 628) / 100);
    }
    for (let i = 0; i < D.cicek; i++) {
      const q = pr([-1.5 + (i % 4) * 1.0 + (i >= 4 ? 0.5 : 0), PV_SAHNE_Y + 0.02, D.sahneZ + 0.18]);
      if (q.ok)
        pvCicekCiz(q.x, q.y - 0.12 * q.s, 0.32 * q.s);
    }
  });
}
// Liste çizildikten sonra: ışık huzmeleri (toplamalı) ve salona yağan para.
function oyunUst() {
  const hedefler = [solist];
  if (D.isik && D.isik.k && !D.isik.k.cikiyor)
    hedefler.push(D.isik.k);
  c.save();
  c.globalCompositeOperation = 'lighter';
  hedefler.forEach((k, i) => {
    const p = pr([k.x, k.y0 || 0, k.z]);
    if (!p.ok)
      return;
    const ux = i === 0 ? GW * 0.5 + Math.sin(TAU * B / 16) * 60 : (p.x < GW / 2 ? GW * 0.08 : GW * 0.92), uy = 0;
    const r = 0.75 * p.s, g = c.createLinearGradient(ux, uy, p.x, p.y);
    const renk = i === 0 ? '255,214,150' : '255,120,190';
    g.addColorStop(0, 'rgba(' + renk + ',0.32)');
    g.addColorStop(1, 'rgba(' + renk + ',0.12)');
    c.fillStyle = g;
    c.beginPath();
    c.moveTo(ux - 12, uy);
    c.lineTo(ux + 12, uy);
    c.lineTo(p.x + r, p.y);
    c.lineTo(p.x - r, p.y);
    c.closePath();
    c.fill();
    c.fillStyle = 'rgba(' + renk + ',0.18)';
    c.beginPath();
    c.ellipse(p.x, p.y, r, r * 0.3, 0, 0, TAU);
    c.fill();
  });
  c.restore();
  for (const y of D.yagmur) {
    const t = B - y.b0;
    if (t < 0)
      continue;
    const yy = -30 + t * y.hiz * 0.5, xx = y.x + Math.sin(y.sal + t * 2.2) * 26;
    if (yy > ALAN_ALT)
      continue;
    pvParaCiz(xx, yy, 34, Math.sin(y.sal + t * 3) * 0.8 + y.don * 0.1);
  }
}
