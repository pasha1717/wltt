/* AYAR — Pavyon Gecesi oyununun bütün yazıları, hediye kademeleri, açılış kalabalığı ve sahte yorumları.
 * Derlemede HER ZAMAN İLK dosyadır; çekirdek OYUN'u buradan okur (docs/KANCALAR.md).
 * Oyun: eski usul bir gece kulübü. Sahnede solist şarkı söyler. Yorum yazan masaya oturur. Hediye atan sahneye
 * peçete, para, çiçek atar; para sahnenin önünde yığılır. En çok hediye atan "gecenin ağası" olur: en öndeki
 * kadife koltuk ve siyah gözlük onundur. En büyük hediyede solist şarkıyı ona okur, gönderen sahneye çıkar.
 */
const OYUN = {
  id: 'pavyon',
  ad: 'Pavyon Gecesi',
  logo: ['Pavyon', 'Gecesi'],
  nasil: { yorum: 'Yorum: masaya otur', begeni: 'Beğeni: alkış', hediye: 'Hediye: sahneye at' },
  yazi: {
    sira: 'Masa sırası', gosterge: 'Alkış', bos: 'Salon boş. İlk oturan gecenin ağası olur.',
    birim: 'masa', ses: 'Orkestrayı başlat', sahne: 'Pavyon sahnesi', giris: 'masaya oturur',
    bosalt: 'Salonu boşalt'
  },
  kapasite: 25,
  // Büyükten küçüğe. Her hediyede gönderen sahneye bir şey atar; tip neyin atılacağını ve ek etkiyi seçer.
  kademe: [
    { min: 1000, ad: 'Bu şarkı senin için', tip: 'sahne', etki: 'Gönderen sahneye çıkar, ışık onda, para yağar' },
    { min: 200, ad: 'Para yağmuru', tip: 'yagmur', etki: 'Bütün salona para yağar' },
    { min: 50, ad: 'Çiçek gönder', tip: 'cicek', etki: 'Solista demet gider, ışık gönderene döner' },
    { min: 10, ad: 'Para saç', tip: 'para', etki: 'Gönderen sahneye para saçar, para yığılır' },
    { min: 1, ad: 'Peçete at', tip: 'pecete', etki: 'Gönderen sahneye peçete atar' }
  ],
  tohum: [['ağa_kemal', 320], ['zeyno.47', 140], ['gece_kuşu', 60], ['plak.cemo', 25], ['elif_naz', 10], ['hasan.usta', 5], ['pınar_34', 0], ['nur.sena', 0]],
  sahteAd: ['ağa_kemal', 'gece_kuşu', 'plak.cemo', 'zeyno.47', 'elif_naz', 'hasan.usta', 'pınar_34', 'nur.sena', 'mert.can.21', 'sibel_abla', 'ozan_dayı', 'yusuf.63', 'nazlı_can', 'şahin_k', 'melo.27', 'fatoş_01', 'kemo_44', 'hüso_baba', 'ayten_hanım', 'selo_02', 'songül.k', 'laz_ziya', 'baran.21', 'arabesk_rıza', 'gazinocu_tayfun', 'kaset.ipek', 'muhtar_emmi', 'efe_tr', 'cano_23', 'sude_nur'],
  sahteYorum: ['bir şarkı daha!', 'ağam kim?', 'garson bakar mısın', 'bu şarkı benim için', 'yaşa be!', 'masaya bir çay', 'peçeteler havada', 'alkışlar solista', 'ben de geldim', 'adımı gördüm', 'para yağmuru gelsin', 'sahneye çık sahneye', 'eski şarkılardan', 'gecenin ağası benim', 'ışıklar söndü', 'bir daha bir daha'],
  // Gece kulübü: koyu bordo duvar, mor ışık, altın varak. Sahne üstü yazılar ve panel aynı paletten.
  renk: { zemin: '#1d0f22', zemin2: '#3a1636', zemin3: '#5b2150', cizgi: '#7a2f68', vurgu: '#ffc94a', sicak: '#ff4f7b', serin: '#59d3ff', soluk: '#c9a7c4' },
  // Önden ve biraz yukarıdan bakan kamera: masalar sıra sıra görünür, arkadaki yükseltilmiş sahne kalabalığın üstünden okunur.
  kamera: { egim: 0.62, F: 1400, ustPay: 2.3, altPay: 0.1 },
  etiket: { ustSinir: true, altSinir: true, disari: 'gizle', balonSira: 'derinlik' },
  sahneYazi: { pankart: 'alt' },
  // Takım: düğün takımı (darbuka, def, klarnet); eski gazino orkestrası havası. İki özgün hava.
  muzik: {
    takim: 'dugun',
    havalar: [
      { id: 'neon', ad: 'Neon', bpm: 106, spb: 4, bar: 16, tonik: 311.1,
        dizi: [0, 100, 400, 500, 700, 800, 1100],                       // hicazkâr
        davul: { ana: 'D.kTT.kTD.kTT.kT', cesni: 'D.kTT.kkD.kTT.rk', gecis: 'D.kkT.kkD.krTrTr' },
        ust: { ana: '......z.......z.', cesni: '..z...z...z...z.', gecis: 'z.z.z.z.z.z.zzzz' },
        bas: { ana: '1.....5.1.......', cesni: '1.....5.1...5...', gecis: '1...5...1...8...' },
        bolum: {
          A: '4:2 5:1 4:1 3:2 2:2 3:4 4:4 | 5:2 6:2 5:2 4:2 3:2 2:2 1:4 | 2:2 3:2 4:4 3:2 2:2 1:2 0:2 | 1:4 -1:2 0:2 0:8',
          B: '7:2 6:2 7:4 8:2 7:2 6:4 | 5:2 4:2 5:2 6:2 5:8 | 4:2 3:2 4:2 5:2 4:2 3:2 2:4 | 1:2 2:2 1:2 0:2 0~:8',
          D: '-:16 -:16'
        },
        eslik: { A: '0:16 4:16 3:16 0:16', B: '0:16 3:16 4:16 0:16' },
        form: 'AABBD' },
      { id: 'geceyarisi', ad: 'Gece Yarısı', bpm: 128, spb: 4, bar: 8, tonik: 349.2,
        dizi: [0, 200, 350, 500, 700, 900, 1050],                       // rast
        davul: { ana: 'D.kTD.Tk', cesni: 'DkkTD.Tr', gecis: 'DkTkTkTr' },
        ust: { ana: '.z.z.z.z', cesni: '.zzz.z.z', gecis: 'zzzzz.zz' },
        bas: { ana: '1.5.1.5.', cesni: '1.5.8.5.', gecis: '1..5.8..' },
        bolum: {
          A: '0:2 2:2 4:2 5:2 | 4:2 2:2 4:4 | 5:2 4:2 2:2 1:2 | 2:4 -:4 | 4:1 5:1 4:1 2:1 4:2 5:2 | 7:2 5:2 4:4 | 2:2 1:2 2:1 1:1 -1:2 | 0:8',
          B: '7:2 7:1 8:1 7:2 5:2 | 4:4 5:4 | 4:2 2:2 4:2 5:2 | 4:4 -:4 | 2:2 4:2 2:2 1:2 | 0:2 1:2 2:4 | 1:2 0:2 -1:2 1:2 | 0~:8',
          D: '-:8 -:8 -:8 -:8'
        },
        eslik: { A: '0:16 4:16 0:16 4:8 0:8', B: '4:16 0:16 4:16 0:16' },
        form: 'AABBD' }
    ]
  }
};
