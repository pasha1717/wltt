/* PAVYON GECESİ — yerleşim, olaylar, hareket ve kişilerin çizimi.
 *
 * İzleyiciler masalarda sıra sıra oturur, kameraya bakar. Arkada yükseltilmiş sahnede solist (izleyici değil)
 * şarkı söyler. Gecenin ağası (lider) en önde, kadife koltukta, siyah gözlüklüdür. Hediye atan sahneye peçete,
 * para ya da çiçek atar (20-ucan.js). Salon, sahne ve ışıklar 30-salon.js'te.
 */

const PV_SIRA = 6;         // bir sırada kaç masa
const PV_ARA_X = 0.9;      // yan yana iki masa arası (metre)
const PV_ARA_Z = 1.1;      // iki sıra arası
const PV_AGA_Z = -1.3;     // gecenin ağası bu kadar önde oturur
const PV_SAHNE_Y = 0.7;    // sahnenin yüksekliği
const PV_OTURAK = 0.45;    // sandalyenin oturağı

Object.assign(D, { sahneZ: 1.6, ucan: [], yagmur: [], yigin: 0, pecete: 0, cicek: 0, sovBit: -1, sov: null, isik: null, alkis: -1 });

// Solist izleyici değildir: D.oy'da durmaz, etiketi oyunEkAdlar'dan gelir.
const solist = karakterYap('__solist', 'Solist');
Object.assign(solist, { mod: 'solist', ozel: true, x: 0, z: 2.2, y0: PV_SAHNE_Y, yon: Math.PI, yer: 1 });
Object.assign(solist.g, { kadin: false, ten: '#e0a878', sac: '#1a1110', boy: 1.22, gomlek: '#f3e6c8', yelek: '#5a1f6e', alt: '#1c1424', kusak: '#ffc94a', baslik: 'yok', biyik: true });
const PV_OZEL = [solist];

function pvHazir(k) {
  if (k.pv)
    return;
  k.pv = { at: -9, atTip: null };
}
// Sahnenin ön kenarı en arkadaki masanın biraz gerisinde; kalabalık büyüdükçe sahne geriye kayar.
function pvSahneHedef() {
  let m = 0;
  for (const k of D.sira)
    if (!k.yildiz)
      m = Math.max(m, k.hedefZ);
  return m + 1.05;
}
function oyunYerlesim() {
  const yildiz = D.sov && D.oy.has(D.sov.k.id) ? D.sov.k : null;
  let i = 0;
  const n0 = D.sira.length - 1 - (yildiz ? 1 : 0);
  for (const k of D.sira) {
    pvHazir(k);
    if (k === yildiz)
      continue;
    if (i === 0) {
      k.hedefX = 0;
      k.hedefZ = PV_AGA_Z;
      i++;
      continue;
    }
    const j = i - 1, s = Math.floor(j / PV_SIRA), n = Math.min(PV_SIRA, n0 - s * PV_SIRA), yer = j % PV_SIRA;
    k.hedefX = (yer - (n - 1) / 2) * PV_ARA_X + (s % 2 ? PV_ARA_X / 2 : 0);
    k.hedefZ = -0.1 + s * PV_ARA_Z;
    i++;
  }
  D.sahneHedef = pvSahneHedef();
  if (yildiz) {
    yildiz.hedefX = 0.95;
    yildiz.hedefZ = D.sahneHedef + 0.55;
  }
}
function oyunGiris(k) {
  pvHazir(k);
  // kapı salonun yanında: yandan yürüyerek gelir
  k.x = (k.hedefX >= 0 ? 1 : -1) * 5.5;
  k.z = k.hedefZ;
}
function oyunBaslat() {
  for (const k of D.sira) {
    pvHazir(k);
    k.x = k.hedefX;
    k.z = k.hedefZ;
    k.yer = 1;
    k.yon = Math.PI;
    k.yeni = -9;
  }
  D.sahneZ = D.sahneHedef || pvSahneHedef();
}
function oyunBosalt() {
  Object.assign(D, { ucan: [], yagmur: [], yigin: 0, pecete: 0, cicek: 0, sovBit: -1, sov: null, isik: null, alkis: -1 });
  muzik.sov = false;
}

/* ---- olaylar ---- */
function oyunHediye(k, jeton, kademe) {
  pvHazir(k);
  const tip = kademe.tip;
  k.pv.at = B;
  k.pv.atTip = tip;
  if (tip === 'pecete')
    pvAt(k, 'pecete', 3);
  else if (tip === 'para') {
    pvAt(k, 'para', 5);
    solist.zip0 = B;
    solist.zip1 = B + 2;
  }
  else if (tip === 'cicek') {
    pvAt(k, 'cicek', 1);
    D.isik = { k, bit: B + 6 };
  }
  else if (tip === 'yagmur') {
    pvAt(k, 'para', 8);
    pvYagmur(70);
    D.sarsinti = 0.4;
  }
  else if (tip === 'sahne') {
    pvAt(k, 'para', 8);
    pvYagmur(110);
    D.sov = { k, b0: B };
    D.sovBit = B + 16;
    D.isik = { k, bit: D.sovBit };
    k.yildiz = true;
    muzik.sov = true;
    D.sarsinti = 0.7;
    konfeti(70, 0.8);
    pankart('Bu şarkı senin için!', k.ad);
  }
}
function oyunLiderDegisti(eski, yeni) {
  pankart(D.sov && D.sov.k === yeni ? 'Bu şarkı ve masa senin!' : 'Gecenin ağası', yeni.ad);
  konfeti(60, 0.8);
}

/* ---- her kare ---- */
function oyunGuncelle(dt) {
  muzik.sov = B < D.sovBit;
  if (D.sov && (B > D.sovBit || D.sov.k.cikiyor)) {
    D.sov.k.yildiz = false;
    D.sov = null;
    oyunYerlesim();
  }
  if (D.isik && B > D.isik.bit)
    D.isik = null;
  D.sahneZ += ((D.sahneHedef || 1.6) - D.sahneZ) * Math.min(1, dt * 2);
  pvUcanGuncelle();
  for (const k of D.oy.values()) {
    pvHazir(k);
    const hx = k.cikiyor ? (k.x >= 0 ? 1 : -1) * 6 : k.hedefX, hz = k.hedefZ;
    const dx = hx - k.x, dz = hz - k.z, uz = Math.hypot(dx, dz);
    if (uz > 0.002) {
      const adim = Math.min(uz, (2.2 + uz * 1.2) * dt);
      k.x += dx / uz * adim;
      k.z += dz / uz * adim;
    }
    k.yer += ((uz < 0.12 && !k.cikiyor ? 1 : 0) - k.yer) * Math.min(1, dt * 7);
    if (k.cikiyor)
      k.gitti = Math.abs(k.x) > 5.8;
    // sahneye çıkan yükselir, inen alçalır
    const yHedef = k.yildiz && uz < 1.2 ? PV_SAHNE_Y : 0;
    k.y0 = (k.y0 || 0) + (yHedef - (k.y0 || 0)) * Math.min(1, dt * 5);
    const bak = uz > 0.3 ? Math.atan2(dx, dz) : Math.PI;
    k.yon += aciFark(k.yon, bak) * Math.min(1, dt * 8);
    k.basOlcek = k === D.lider ? 1.18 : undefined;
    pvPoz(k);
  }
  pvSolist(dt);
}
// Oturan izleyici: eller masada, coşku yükselince vuruşta alkış; hediye atanın sağ eli havaya kalkar.
function pvPoz(k) {
  const oturur = k.yer > 0.6 && !k.yildiz;
  const poz = oturur ? pozOtur(k, PV_OTURAK) : pozBekle(k);
  const W = iskeletKur(k, poz), hy = poz.hipY, at = B - k.pv.at;
  const alkis = D.cosku > 0.55 || B < D.alkis, ac = alkis ? 0.07 + 0.06 * Math.abs(Math.sin(Math.PI * B * 2 + k.g.salin * 3)) : 0;
  if (k.yildiz) {
    // sahnede: iki kol havada, vuruşla sallanır
    const s = 0.08 * Math.sin(TAU * B / 2);
    k.j.haR = W(-0.34 + s, hy + 0.85, 0.08);
    k.j.haL = W(0.34 + s, hy + 0.85, 0.08);
    k.elSekil = { R: 'avuc', L: 'avuc' };
  }
  else if (at >= 0 && at < 1.2) {
    // atış: sağ el yukarıdan öne savrulur
    const u = at / 1.2;
    k.j.haR = W(-0.22, hy + 0.55 + 0.25 * Math.sin(Math.PI * u), 0.15 + 0.25 * u);
    k.j.haL = W(0.12, hy + 0.32, 0.25);
    k.elSekil = { R: 'avuc' };
  }
  else if (oturur && alkis) {
    k.j.haR = W(-ac, hy + 0.42, 0.3);
    k.j.haL = W(ac, hy + 0.42, 0.3);
    k.elSekil = { R: 'avuc', L: 'avuc' };
  }
  else if (oturur) {
    k.j.haR = W(-0.16, hy + 0.28, 0.32);
    k.j.haL = W(0.16, hy + 0.28, 0.32);
    k.elSekil = null;
  }
  else {
    k.j.haR = W(-0.2, hy + 0.06, 0.05);
    k.j.haL = W(0.2, hy + 0.06, 0.05);
    k.elSekil = null;
  }
  kolKur(k);
}
// Solist: sahnenin ortasında, mikrofon sağ elinde ağzının önünde, sol eli vuruşla açılıp kapanır.
function pvSolist(dt) {
  const m = solist, hz = D.sahneZ + 0.65, hx = D.sov ? -0.6 : 0;
  m.x += (hx - m.x) * Math.min(1, dt * 3);
  m.z += (hz - m.z) * Math.min(1, dt * 3);
  m.y0 = PV_SAHNE_Y;
  const bak = D.sov ? Math.PI + 0.5 : Math.PI + 0.25 * Math.sin(TAU * B / 8);
  m.yon += aciFark(m.yon, bak) * Math.min(1, dt * 5);
  m.guler = B < m.zip1 || !!D.sov;
  const poz = pozBekle(m);
  const W = iskeletKur(m, poz), hy = poz.hipY, ac = 0.5 + 0.5 * Math.sin(TAU * B / 2);
  m.j.haR = W(-0.08, hy + 0.66, 0.2);
  m.j.haL = W(0.18 + 0.2 * ac, hy + 0.35 + 0.3 * ac, 0.18);
  m.elSekil = { R: 'yumruk', L: 'avuc' };
  kolKur(m);
  m.mik = W(-0.06, hy + 0.76, 0.27);
}
function oyunKamera() {
  const zs = D.sahneZ, n = [[2.2, PV_AGA_Z - 0.6], [-2.2, PV_AGA_Z - 0.6], [2.4, zs + 0.7], [-2.4, zs + 0.7]];
  for (const k of D.sira)
    n.push([k.hedefX, k.hedefZ]);
  return n;
}
function oyunCiz() {
  for (const k of D.oy.values()) {
    if (!insanEkle(k))
      continue;
    if (k.hedefZ < 0.5 && k !== D.lider && !k.yildiz)
      k.et.asagi = true;
    if (!k.yildiz && k.yer > 0.6)
      pvMasaEkle(k);
    if (k === D.lider)
      pvGozlukEkle(k);
  }
  if (insanEkle(solist))
    pvMikrofonEkle(solist);
  pvSahneEkle();
  pvUcanEkle();
}
function oyunEkAdlar() { return PV_OZEL; }
function oyunDurum(d) {
  d.aga = D.lider ? D.lider.ad : null;
  d.yigin = D.yigin;
  d.sahnede = D.sov ? D.sov.k.ad : null;
}
