/* SALON — arka duvar, perde, neon yazı, ayna küre, zemin, yükseltilmiş sahne; masalar, koltuklar, gözlük, mikrofon. */

const PV_PERDE = '#8e1b3a', PV_PERDE2 = '#5e0f27', PV_ALTIN = '#e7b64a';

function oyunZemin() {
  const zs = D.sahneZ, duvarZ = zs + 1.7;
  // zemin ve duvar: önce bütün tuvali koyu mora boya
  const g = c.createLinearGradient(0, 0, 0, GH);
  g.addColorStop(0, '#12081a');
  g.addColorStop(0.5, '#24102c');
  g.addColorStop(1, '#170a1e');
  c.fillStyle = g;
  c.fillRect(0, 0, GW, GH);
  // zemin karoları: yakında iri, uzakta ince; vuruşla yanıp sönen birkaç renkli karo
  const W = 7;
  for (let z = -3; z < duvarZ; z += 0.7)
    for (let x = -W; x < W; x += 0.7) {
      const a = pr([x, 0, z]), b = pr([x + 0.7, 0, z]), cc = pr([x + 0.7, 0, z + 0.7]), d = pr([x, 0, z + 0.7]);
      if (!a.ok || !cc.ok)
        continue;
      const i = Math.round(x / 0.7) + Math.round(z / 0.7) * 7, yan = (ozet('k' + i) + Math.floor(B)) % 9 === 0;
      c.fillStyle = yan ? renkKat('#ff4f7b', '#2a1030', 0.55 - 0.3 * calgi.dumP) : (i & 1 ? '#2a1432' : '#1f0e26');
      c.beginPath();
      c.moveTo(a.x, a.y);
      c.lineTo(b.x, b.y);
      c.lineTo(cc.x, cc.y);
      c.lineTo(d.x, d.y);
      c.closePath();
      c.fill();
    }
  pvDuvar(duvarZ);
  pvSahne(zs);
  for (const k of D.oy.values())
    golge(k.x, k.z, 0.25 * k.g.boy, 0.13 * k.g.boy);
  if (D.lider && !D.lider.yildiz) {
    const p = pr([D.lider.x, 0, D.lider.z]);
    if (p.ok) {
      const n = 1 + 0.08 * Math.sin(B * TAU);
      c.strokeStyle = RENK.vurgu;
      c.lineWidth = Math.max(2, p.s * 0.03);
      c.beginPath();
      c.ellipse(p.x, p.y, 0.55 * p.s * n, 0.25 * p.s * n, 0, 0, TAU);
      c.stroke();
    }
  }
}
// Arka duvar: kat kat kırmızı perde, üstte neon yazı ve dönen ayna küre.
function pvDuvar(z) {
  const W = 7, H = 4.2;
  const a = pr([-W, 0, z]), b = pr([W, H, z]);
  if (!a.ok || !b.ok)
    return;
  const ust = Math.min(a.y, b.y);
  c.fillStyle = PV_PERDE2;
  c.fillRect(0, Math.max(0, b.y - 400), GW, a.y - Math.max(0, b.y - 400));
  // perde kıvrımları
  const adim = 0.45;
  for (let x = -W; x < W; x += adim) {
    const p = pr([x, 0, z]), q = pr([x + adim, 0, z]);
    if (!p.ok || !q.ok)
      continue;
    const g = c.createLinearGradient(p.x, 0, q.x, 0);
    g.addColorStop(0, PV_PERDE2);
    g.addColorStop(0.5, PV_PERDE);
    g.addColorStop(1, PV_PERDE2);
    c.fillStyle = g;
    c.fillRect(p.x, 0, q.x - p.x + 1, p.y);
  }
  // perdenin üst saçağı: altın şerit
  const sc = pr([0, 3.1, z]);
  if (sc.ok) {
    c.fillStyle = PV_ALTIN;
    c.fillRect(0, sc.y - 6, GW, 6);
  }
  // neon yazı
  const ny = pr([0, 2.55, z]);
  if (ny.ok) {
    const boy = Math.max(18, 0.42 * ny.s), parla = 0.75 + 0.25 * calgi.dumP;
    c.save();
    c.font = boy + 'px "Paytone One", Rubik, system-ui, sans-serif';
    c.textAlign = 'center';
    c.textBaseline = 'middle';
    c.lineJoin = 'round';
    c.globalAlpha = 0.35 * parla;
    c.strokeStyle = '#ff4f9a';
    c.lineWidth = boy * 0.32;
    c.strokeText('GECE', ny.x, ny.y);
    c.globalAlpha = 1;
    c.strokeStyle = '#ff7ab8';
    c.lineWidth = boy * 0.1;
    c.strokeText('GECE', ny.x, ny.y);
    c.fillStyle = '#ffe3f1';
    c.fillText('GECE', ny.x, ny.y);
    c.restore();
  }
  // ayna küre: neon yazının üstünde, yansımaları duvara düşer
  const kp = pr([2.4, 2.6, z - 0.3]);
  if (kp.ok) {
    const r = 0.28 * kp.s;
    c.strokeStyle = '#6a5a70';
    c.lineWidth = 1.5;
    c.beginPath();
    c.moveTo(kp.x, kp.y - r);
    c.lineTo(kp.x, Math.max(0, ust - 200));
    c.stroke();
    c.fillStyle = '#c8c4d8';
    c.beginPath();
    c.arc(kp.x, kp.y, r, 0, TAU);
    c.fill();
    for (let i = 0; i < 14; i++) {
      const a = i / 14 * TAU + B * 0.6, yy = Math.sin(i * 1.7);
      c.fillStyle = (i + Math.floor(B * 2)) % 3 ? '#8d86a3' : '#ffffff';
      c.fillRect(kp.x + Math.cos(a) * r * 0.65 - 2, kp.y + yy * r * 0.65 - 2, 4, 4);
    }
    // duvardaki ışık benekleri
    c.fillStyle = 'rgba(255,240,250,0.35)';
    for (let i = 0; i < 18; i++) {
      const a = i / 18 * TAU + B * 0.25, x = kp.x + Math.cos(a) * (120 + (i % 3) * 70), y = kp.y + 40 + Math.sin(a * 1.3) * 90;
      c.beginPath();
      c.arc(x, y, 2.5, 0, TAU);
      c.fill();
    }
  }
}
// Yükseltilmiş sahne: üstü cilalı tahta, önü altın şeritli koyu bordo.
function pvSahne(zs) {
  const W = 3.4, H = PV_SAHNE_Y, z1 = zs + 1.7;
  const a = pr([-W, H, zs]), b = pr([W, H, zs]), cc = pr([W, H, z1]), d = pr([-W, H, z1]);
  const a0 = pr([-W, 0, zs]), b0 = pr([W, 0, zs]);
  if (!a.ok || !b.ok || !a0.ok || !b0.ok)
    return;
  c.lineWidth = Math.max(1, a.s * 0.01);
  c.strokeStyle = MUREKKEP;
  c.fillStyle = '#3b1530';
  c.beginPath();
  c.moveTo(a0.x, a0.y);
  c.lineTo(b0.x, b0.y);
  c.lineTo(b.x, b.y);
  c.lineTo(a.x, a.y);
  c.closePath();
  c.fill();
  c.stroke();
  // ön yüzdeki küçük ampuller, vuruşla sırayla yanar
  for (let i = 0; i <= 16; i++) {
    const p = pr([-W + i * (2 * W / 16), H * 0.5, zs - 0.01]);
    if (!p.ok)
      continue;
    const yan = (i + Math.floor(B * 2)) % 3 === 0;
    c.fillStyle = yan ? '#fff0b8' : '#8a5a3a';
    c.beginPath();
    c.arc(p.x, p.y, Math.max(1.5, 0.03 * p.s), 0, TAU);
    c.fill();
  }
  const g = c.createLinearGradient(0, d.y, 0, a.y);
  g.addColorStop(0, '#5a2a1c');
  g.addColorStop(1, '#8a4a2a');
  c.fillStyle = g;
  c.beginPath();
  c.moveTo(a.x, a.y);
  c.lineTo(b.x, b.y);
  c.lineTo(cc.x, cc.y);
  c.lineTo(d.x, d.y);
  c.closePath();
  c.fill();
  c.stroke();
  c.strokeStyle = PV_ALTIN;
  c.lineWidth = Math.max(2, a.s * 0.025);
  c.beginPath();
  c.moveTo(a.x, a.y);
  c.lineTo(b.x, b.y);
  c.stroke();
}
// Sahnenin iki yanında hoparlörler (derinliğe göre sıralanır: sahnede duranın önüne ya da arkasına düşer).
function pvSahneEkle() {
  for (const s of [-1, 1]) {
    const x = s * 2.9, z = D.sahneZ + 0.5, m = pr([x, PV_SAHNE_Y + 0.4, z]);
    if (!m.ok)
      continue;
    ozel(m.d, () => {
      const T = donusum(x, PV_SAHNE_Y, z, Math.PI, 1), cz = Math.max(1, m.s * 0.01);
      const g = kutuCiz(T, -0.3, 0.3, 0, 0.95, -0.25, 0.25, '#221a26', cz);
      if (g.on) {
        for (const [yy, r] of [[0.65, 0.17], [0.27, 0.12]]) {
          const p = pr(yerelNokta(T, 0, yy, 0.26));
          if (p.ok)
            daireCiz(p, r * (1 + 0.08 * calgi.dumP), '#3b3242', cz);
        }
      }
    });
  }
}
// Masa: kişinin önünde, beyaz örtülü yuvarlak masa ve üstünde titreyen mum; arkasında sandalye arkalığı.
// Ağanın masası altın örtülü, arkasında kadife koltuk.
function pvMasaEkle(k) {
  const aga = k === D.lider, mz = k.z - 0.45, r = aga ? 0.34 : 0.26, yuk = 0.62;
  const ust = pr([k.x, yuk, mz]), alt = pr([k.x, 0, mz]);
  if (ust.ok && alt.ok)
    ozel(ust.d - 0.02, () => {
      const cz = Math.max(1, ust.s * 0.01);
      kapsulCiz(alt, 0.04, ust, 0.04, '#2a1a22', cz);
      c.fillStyle = aga ? PV_ALTIN : '#f4eee2';
      c.strokeStyle = MUREKKEP;
      c.lineWidth = cz;
      c.beginPath();
      c.ellipse(ust.x, ust.y, r * ust.s, r * ust.s * 0.36, 0, 0, Math.PI);
      c.lineTo(ust.x - r * ust.s, ust.y);
      c.fill();
      // örtünün sarkan eteği
      c.beginPath();
      c.moveTo(ust.x - r * ust.s, ust.y);
      c.lineTo(ust.x - r * ust.s * 0.95, ust.y + 0.16 * ust.s);
      c.quadraticCurveTo(ust.x, ust.y + 0.26 * ust.s, ust.x + r * ust.s * 0.95, ust.y + 0.16 * ust.s);
      c.lineTo(ust.x + r * ust.s, ust.y);
      c.closePath();
      c.fill();
      c.stroke();
      c.beginPath();
      c.ellipse(ust.x, ust.y, r * ust.s, r * ust.s * 0.36, 0, 0, TAU);
      c.fill();
      c.stroke();
      // mum
      const mp = pr([k.x + r * 0.45, yuk + 0.07, mz]);
      if (mp.ok) {
        c.fillStyle = '#f7ead0';
        c.fillRect(mp.x - 0.015 * mp.s, mp.y - 0.06 * mp.s, 0.03 * mp.s, 0.1 * mp.s);
        const tit = 0.8 + 0.2 * Math.sin(zaman * 23 + k.pv.at);
        c.fillStyle = 'rgba(255,190,90,0.25)';
        c.beginPath();
        c.arc(mp.x, mp.y - 0.08 * mp.s, 0.08 * mp.s * tit, 0, TAU);
        c.fill();
        c.fillStyle = '#ffd27a';
        c.beginPath();
        c.ellipse(mp.x, mp.y - 0.08 * mp.s, 0.014 * mp.s, 0.03 * mp.s * tit, 0, 0, TAU);
        c.fill();
      }
    });
  // arkalık: gövdenin arkasında
  const sz = k.z + 0.2, sa = pr([k.x, 0.45, sz]), su = pr([k.x, aga ? 1.25 : 0.95, sz]);
  if (sa.ok && su.ok)
    ozel(sa.d + 0.3, () => {
      const cz = Math.max(1, sa.s * 0.01), gen = (aga ? 0.36 : 0.22) * sa.s;
      c.fillStyle = aga ? '#9b1838' : '#4a2a3a';
      c.strokeStyle = MUREKKEP;
      c.lineWidth = cz;
      c.beginPath();
      c.roundRect(su.x - gen, su.y, gen * 2, sa.y - su.y, gen * 0.5);
      c.fill();
      c.stroke();
      if (aga) {
        c.strokeStyle = PV_ALTIN;
        c.lineWidth = Math.max(1.5, sa.s * 0.02);
        c.beginPath();
        c.roundRect(su.x - gen * 0.8, su.y + gen * 0.2, gen * 1.6, (sa.y - su.y) * 0.8, gen * 0.4);
        c.stroke();
      }
    });
}
// Gecenin ağasının siyah gözlüğü.
function pvGozlukEkle(k) {
  const ph = k.p.kafa;
  if (!ph || !ph.ok)
    return;
  const R = KAFA_R * k.g.boy * (k.basOlcek || 1) * ph.s;
  ozel(ph.d - 0.06, () => {
    const x = ph.x, y = ph.y - R * 0.02;
    c.fillStyle = '#121018';
    c.strokeStyle = PV_ALTIN;
    c.lineWidth = Math.max(1, R * 0.06);
    for (const s of [-1, 1]) {
      c.beginPath();
      c.ellipse(x + s * R * 0.38, y, R * 0.3, R * 0.21, 0, 0, TAU);
      c.fill();
      c.stroke();
    }
    c.beginPath();
    c.moveTo(x - R * 0.1, y - R * 0.04);
    c.lineTo(x + R * 0.1, y - R * 0.04);
    c.stroke();
    c.fillStyle = 'rgba(255,255,255,0.5)';
    for (const s of [-1, 1]) {
      c.beginPath();
      c.ellipse(x + s * R * 0.38 - R * 0.1, y - R * 0.07, R * 0.07, R * 0.04, -0.5, 0, TAU);
      c.fill();
    }
  });
}
// Solistin mikrofonu: elinin önünde, ağzına doğru.
function pvMikrofonEkle(m) {
  const ha = m.p.haR;
  if (!ha || !ha.ok || !m.mik)
    return;
  const uc = pr(m.mik);
  if (!uc.ok)
    return;
  ozel(ha.d - 0.04, () => {
    const cz = Math.max(1, ha.s * 0.01);
    kapsulCiz(ha, 0.03, uc, 0.025, '#2a2a32', cz);
    daireCiz(uc, 0.05, '#9a9aa8', cz);
  });
}
